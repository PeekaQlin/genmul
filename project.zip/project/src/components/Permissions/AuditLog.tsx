import React, { useState } from 'react';
import { Eye, Calendar, User, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { Table } from '../Common/Table';
import { Modal } from '../Common/Modal';
import { AuditLog } from '../../types';
import { useAuth } from '../../hooks/useAuth';

export const AuditLogList: React.FC = () => {
  const { getAuditLogs, isSuperAdmin } = useAuth();
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    eventType: '',
    dateRange: ['', '']
  });

  // 只有超级管理员可以查看审计日志
  if (!isSuperAdmin()) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">访问受限</h3>
          <p className="text-gray-600">只有超级管理员可以查看审计日志</p>
        </div>
      </div>
    );
  }

  const auditLogs = getAuditLogs();

  const columns = [
    {
      key: 'timestamp',
      title: '时间',
      width: '15%',
      render: (timestamp: string) => (
        <div className="text-sm">
          {new Date(timestamp).toLocaleString()}
        </div>
      )
    },
    {
      key: 'operatorName',
      title: '操作人',
      width: '12%',
      render: (operatorName: string) => (
        <div className="flex items-center space-x-2">
          <User className="w-4 h-4 text-gray-400" />
          <span>{operatorName}</span>
        </div>
      )
    },
    {
      key: 'eventType',
      title: '事件类型',
      width: '15%',
      render: (eventType: string) => {
        const eventMap = {
          GRANT_CREATED: { text: '创建授权', color: 'bg-green-100 text-green-800' },
          GRANT_REVOKED: { text: '撤销授权', color: 'bg-red-100 text-red-800' },
          SENSITIVE_FIELD_ACCESS: { text: '敏感字段访问', color: 'bg-yellow-100 text-yellow-800' },
          DATA_ACCESS: { text: '数据访问', color: 'bg-blue-100 text-blue-800' },
          DATA_MODIFIED: { text: '数据修改', color: 'bg-purple-100 text-purple-800' }
        };
        const event = eventMap[eventType as keyof typeof eventMap];
        return (
          <span className={`px-2 py-1 rounded-full text-xs ${event?.color || 'bg-gray-100 text-gray-800'}`}>
            {event?.text || eventType}
          </span>
        );
      }
    },
    {
      key: 'targetEntity',
      title: '目标实体',
      width: '12%'
    },
    {
      key: 'targetId',
      title: '目标ID',
      width: '15%',
      render: (targetId: string) => (
        <code className="text-xs bg-gray-100 px-2 py-1 rounded">{targetId}</code>
      )
    },
    {
      key: 'details',
      title: '详情',
      width: '20%',
      render: (details: Record<string, any>) => (
        <div className="text-sm text-gray-600">
          {details?.error && (
            <div className="flex items-center space-x-1 text-red-600">
              <XCircle className="w-3 h-3" />
              <span>错误: {details.error}</span>
            </div>
          )}
          {details?.granteeId && (
            <div>被授权人: {details.granteeId}</div>
          )}
          {details?.field && (
            <div>字段: {details.field}</div>
          )}
          {details?.blocked && (
            <div className="text-red-600">已阻止访问</div>
          )}
        </div>
      )
    },
    {
      key: 'actions',
      title: '操作',
      width: '8%',
      render: (_: any, record: AuditLog) => (
        <button
          onClick={() => handleViewDetail(record)}
          className="p-1 text-blue-600 hover:bg-blue-50 rounded"
          title="查看详情"
        >
          <Eye className="w-4 h-4" />
        </button>
      )
    }
  ];

  const handleViewDetail = (log: AuditLog) => {
    setSelectedLog(log);
    setDetailModalOpen(true);
  };

  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch = 
      log.operatorName.toLowerCase().includes(searchValue.toLowerCase()) ||
      log.targetEntity.toLowerCase().includes(searchValue.toLowerCase()) ||
      log.targetId.toLowerCase().includes(searchValue.toLowerCase());
    
    const matchesEventType = !filters.eventType || log.eventType === filters.eventType;
    
    return matchesSearch && matchesEventType;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">审计日志</h2>
          <p className="text-gray-600 mt-1">
            系统操作审计记录，仅超级管理员可查看
          </p>
        </div>
      </div>

      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
          <div>
            <h4 className="font-medium text-red-900">安全审计说明</h4>
            <p className="text-sm text-red-700 mt-1">
              • 记录所有权限相关操作和敏感数据访问<br/>
              • 包含操作时间、操作人、目标对象等关键信息<br/>
              • 支持按事件类型和时间范围筛选<br/>
              • 所有记录不可删除或修改，确保审计完整性
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              事件类型
            </label>
            <select
              value={filters.eventType}
              onChange={(e) => setFilters({ ...filters, eventType: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">全部事件</option>
              <option value="GRANT_CREATED">创建授权</option>
              <option value="GRANT_REVOKED">撤销授权</option>
              <option value="SENSITIVE_FIELD_ACCESS">敏感字段访问</option>
              <option value="DATA_ACCESS">数据访问</option>
              <option value="DATA_MODIFIED">数据修改</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              开始时间
            </label>
            <input
              type="datetime-local"
              value={filters.dateRange[0]}
              onChange={(e) => setFilters({ 
                ...filters, 
                dateRange: [e.target.value, filters.dateRange[1]] 
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              结束时间
            </label>
            <input
              type="datetime-local"
              value={filters.dateRange[1]}
              onChange={(e) => setFilters({ 
                ...filters, 
                dateRange: [filters.dateRange[0], e.target.value] 
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      <Table
        columns={columns}
        data={filteredLogs}
        searchable
        searchValue={searchValue}
        onSearch={setSearchValue}
        pagination={{
          current: currentPage,
          total: filteredLogs.length,
          pageSize: 20,
          onChange: setCurrentPage
        }}
      />

      {/* 详情模态框 */}
      <Modal
        open={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="审计日志详情"
        width="max-w-2xl"
      >
        {selectedLog && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">事件ID</label>
                <p className="mt-1 text-sm text-gray-900 font-mono">{selectedLog.id}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">时间戳</label>
                <p className="mt-1 text-sm text-gray-900">
                  {new Date(selectedLog.timestamp).toLocaleString()}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">操作人</label>
                <p className="mt-1 text-sm text-gray-900">
                  {selectedLog.operatorName} ({selectedLog.operatorId})
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">事件类型</label>
                <p className="mt-1 text-sm text-gray-900">{selectedLog.eventType}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">目标实体</label>
                <p className="mt-1 text-sm text-gray-900">{selectedLog.targetEntity}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">目标ID</label>
                <p className="mt-1 text-sm text-gray-900 font-mono">{selectedLog.targetId}</p>
              </div>
            </div>
            
            {selectedLog.details && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">详细信息</label>
                <div className="bg-gray-50 rounded-lg p-3">
                  <pre className="text-sm text-gray-800 whitespace-pre-wrap">
                    {JSON.stringify(selectedLog.details, null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};