import React, { useState } from 'react';
import { Edit, Shield, Trash2, Plus, UserCheck } from 'lucide-react';
import { Table } from '../Common/Table';
import { Modal } from '../Common/Modal';
import { User } from '../../types';

export const AdminList: React.FC = () => {
  const [admins, setAdmins] = useState<User[]>([
    {
      id: '1',
      username: 'admin',
      role: 'super_admin',
      email: 'admin@example.com',
      createdAt: '2024-01-01',
      status: 'active'
    },
    {
      id: '2',
      username: 'manager',
      role: 'admin',
      email: 'manager@example.com',
      createdAt: '2024-01-15',
      status: 'active'
    },
    {
      id: '3',
      username: 'operator',
      role: 'operator',
      email: 'operator@example.com',
      createdAt: '2024-01-20',
      status: 'inactive'
    }
  ]);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<User | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const columns = [
    {
      key: 'username',
      title: '用户名',
      width: '20%'
    },
    {
      key: 'email',
      title: '邮箱',
      width: '25%'
    },
    {
      key: 'role',
      title: '角色',
      width: '15%',
      render: (role: string) => {
        const roleMap = {
          super_admin: '超级管理员',
          admin: '管理员',
          operator: '操作员'
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs ${
            role === 'super_admin' ? 'bg-red-100 text-red-800' :
            role === 'admin' ? 'bg-blue-100 text-blue-800' :
            'bg-green-100 text-green-800'
          }`}>
            {roleMap[role as keyof typeof roleMap]}
          </span>
        );
      }
    },
    {
      key: 'status',
      title: '状态',
      width: '10%',
      render: (status: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          status === 'active' 
            ? 'bg-green-100 text-green-800' 
            : 'bg-gray-100 text-gray-800'
        }`}>
          {status === 'active' ? '启用' : '禁用'}
        </span>
      )
    },
    {
      key: 'createdAt',
      title: '创建时间',
      width: '15%'
    },
    {
      key: 'actions',
      title: '操作',
      width: '15%',
      render: (_: any, record: User) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleEdit(record)}
            className="p-1 text-blue-600 hover:bg-blue-50 rounded"
            title="编辑"
          >
            <Edit className="w-4 h-4" />
          </button>
          <button
            onClick={() => handlePermissions(record)}
            className="p-1 text-green-600 hover:bg-green-50 rounded"
            title="权限配置"
          >
            <Shield className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleDelete(record.id)}
            className="p-1 text-red-600 hover:bg-red-50 rounded"
            title="删除"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  const handleEdit = (admin: User) => {
    setEditingAdmin(admin);
    setModalOpen(true);
  };

  const handlePermissions = (admin: User) => {
    console.log('配置权限:', admin);
  };

  const handleDelete = (adminId: string) => {
    if (confirm('确定要删除这个管理员吗？')) {
      setAdmins(admins.filter(a => a.id !== adminId));
    }
  };

  const handleAdd = () => {
    setEditingAdmin(null);
    setModalOpen(true);
  };

  const filteredAdmins = admins.filter(admin =>
    admin.username.toLowerCase().includes(searchValue.toLowerCase()) ||
    admin.email.toLowerCase().includes(searchValue.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">管理员列表</h2>
        <button
          onClick={handleAdd}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          新增管理员
        </button>
      </div>

      <Table
        columns={columns}
        data={filteredAdmins}
        searchable
        searchValue={searchValue}
        onSearch={setSearchValue}
        pagination={{
          current: currentPage,
          total: filteredAdmins.length,
          pageSize: 10,
          onChange: setCurrentPage
        }}
      />

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingAdmin ? '编辑管理员' : '新增管理员'}
        footer={
          <>
            <button
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              取消
            </button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
              保存
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                用户名
              </label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                defaultValue={editingAdmin?.username}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                邮箱
              </label>
              <input
                type="email"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                defaultValue={editingAdmin?.email}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                角色
              </label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                defaultValue={editingAdmin?.role}
              >
                <option value="super_admin">超级管理员</option>
                <option value="admin">管理员</option>
                <option value="operator">操作员</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                状态
              </label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                defaultValue={editingAdmin?.status}
              >
                <option value="active">启用</option>
                <option value="inactive">禁用</option>
              </select>
            </div>
          </div>
          {!editingAdmin && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                密码
              </label>
              <input
                type="password"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="请输入密码"
              />
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
};