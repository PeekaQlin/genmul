import React, { useState } from 'react';
import { ChevronRight, ChevronDown, Check } from 'lucide-react';
import { Permission } from '../../types';

export const PermissionConfig: React.FC = () => {
  const [permissions] = useState<Permission[]>([
    {
      id: '1',
      name: '流程对接',
      code: 'workflow',
      type: 'function',
      children: [
        { id: '1-1', name: '系统管理', code: 'system', type: 'function' },
        { id: '1-2', name: '流程管理', code: 'process', type: 'function' },
        { id: '1-3', name: '节点管理', code: 'node', type: 'function' }
      ]
    },
    {
      id: '2',
      name: '角色权限',
      code: 'permission',
      type: 'function',
      children: [
        { id: '2-1', name: '管理员列表', code: 'admin_list', type: 'function' },
        { id: '2-2', name: '权限配置', code: 'permission_config', type: 'function' }
      ]
    },
    {
      id: '3',
      name: '数据管理',
      code: 'data',
      type: 'function',
      children: [
        { id: '3-1', name: '审批数据', code: 'approval_data', type: 'data' }
      ]
    },
    {
      id: '4',
      name: '数据权限',
      code: 'data_permission',
      type: 'data',
      children: [
        { id: '4-1', name: '本部门数据', code: 'department_data', type: 'data' },
        { id: '4-2', name: '全部数据', code: 'all_data', type: 'data' },
        { id: '4-3', name: '个人数据', code: 'personal_data', type: 'data' }
      ]
    }
  ]);

  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(['1', '2', '3', '4']));
  const [checkedNodes, setCheckedNodes] = useState<Set<string>>(new Set());
  const [selectedRole, setSelectedRole] = useState('admin');

  const toggleExpand = (nodeId: string) => {
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(nodeId)) {
      newExpanded.delete(nodeId);
    } else {
      newExpanded.add(nodeId);
    }
    setExpandedNodes(newExpanded);
  };

  const toggleCheck = (nodeId: string) => {
    const newChecked = new Set(checkedNodes);
    if (newChecked.has(nodeId)) {
      newChecked.delete(nodeId);
    } else {
      newChecked.add(nodeId);
    }
    setCheckedNodes(newChecked);
  };

  const renderPermissionNode = (permission: Permission, level: number = 0) => {
    const isExpanded = expandedNodes.has(permission.id);
    const isChecked = checkedNodes.has(permission.id);
    const hasChildren = permission.children && permission.children.length > 0;

    return (
      <div key={permission.id} className={`ml-${level * 6}`}>
        <div className="flex items-center space-x-2 py-2 hover:bg-gray-50 rounded-md px-2">
          {hasChildren ? (
            <button
              onClick={() => toggleExpand(permission.id)}
              className="p-1"
            >
              {isExpanded ? (
                <ChevronDown className="w-4 h-4 text-gray-500" />
              ) : (
                <ChevronRight className="w-4 h-4 text-gray-500" />
              )}
            </button>
          ) : (
            <div className="w-6" />
          )}
          
          <label className="flex items-center space-x-2 cursor-pointer flex-1">
            <input
              type="checkbox"
              checked={isChecked}
              onChange={() => toggleCheck(permission.id)}
              className="sr-only"
            />
            <div className={`w-4 h-4 border rounded flex items-center justify-center ${
              isChecked ? 'bg-blue-600 border-blue-600' : 'border-gray-300'
            }`}>
              {isChecked && <Check className="w-3 h-3 text-white" />}
            </div>
            <span className="text-sm text-gray-700">{permission.name}</span>
            <span className={`px-2 py-0.5 rounded text-xs ${
              permission.type === 'function' 
                ? 'bg-blue-100 text-blue-800' 
                : 'bg-green-100 text-green-800'
            }`}>
              {permission.type === 'function' ? '功能' : '数据'}
            </span>
          </label>
        </div>
        
        {hasChildren && isExpanded && (
          <div className="ml-4">
            {permission.children!.map(child => renderPermissionNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">权限配置</h2>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          保存配置
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            选择角色
          </label>
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="w-48 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="admin">管理员</option>
            <option value="operator">操作员</option>
          </select>
        </div>

        <div className="border-t border-gray-200 pt-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">权限树</h3>
          <div className="space-y-1">
            {permissions.map(permission => renderPermissionNode(permission))}
          </div>
        </div>
      </div>

      <div className="bg-blue-50 rounded-lg p-4">
        <h4 className="font-medium text-blue-900 mb-2">已选择权限</h4>
        <div className="flex flex-wrap gap-2">
          {Array.from(checkedNodes).map(nodeId => {
            const findNode = (nodes: Permission[]): Permission | null => {
              for (const node of nodes) {
                if (node.id === nodeId) return node;
                if (node.children) {
                  const found = findNode(node.children);
                  if (found) return found;
                }
              }
              return null;
            };
            
            const node = findNode(permissions);
            return node ? (
              <span
                key={nodeId}
                className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-sm"
              >
                {node.name}
              </span>
            ) : null;
          })}
        </div>
      </div>
    </div>
  );
};