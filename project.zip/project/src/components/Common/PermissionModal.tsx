import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, UserPlus, Calendar, AlertTriangle } from 'lucide-react';
import { Modal } from './Modal';
import { Grant } from '../../types';
import { useAuth } from '../../hooks/useAuth';

interface PermissionModalProps {
  open: boolean;
  onClose: () => void;
  data: {
    dataType: 'system' | 'process' | 'node';
    dataId: string;
    dataName: string;
  } | null;
  onSave: () => void;
}

interface UserOption {
  id: string;
  username: string;
  email: string;
  role: string;
}

export const PermissionModal: React.FC<PermissionModalProps> = ({
  open,
  onClose,
  data,
  onSave
}) => {
  const { user: currentUser, getGrants, createGrant, revokeGrant, hasPermission } = useAuth();
  const [grants, setGrants] = useState<Grant[]>([]);
  const [availableUsers] = useState<UserOption[]>([
    { id: '2', username: 'manager', email: 'manager@example.com', role: 'admin' },
    { id: '3', username: 'operator', email: 'operator@example.com', role: 'operator' },
    { id: '4', username: 'user1', email: 'user1@example.com', role: 'operator' },
    { id: '5', username: 'user2', email: 'user2@example.com', role: 'operator' }
  ]);
  const [selectedUser, setSelectedUser] = useState('');
  const [selectedPermissions, setSelectedPermissions] = useState<('view' | 'edit' | 'grant')[]>([]);
  const [expiresAt, setExpiresAt] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (data) {
      const allGrants = getGrants();
      const dataGrants = allGrants.filter(grant => 
        grant.dataId === data.dataId && 
        grant.dataType === data.dataType &&
        grant.status === 'active'
      );
      setGrants(dataGrants);
    }
  }, [data]);

  const handleAddGrant = async () => {
    if (!selectedUser || selectedPermissions.length === 0 || !currentUser || !data) return;
    
    setError('');

    const userOption = availableUsers.find(u => u.id === selectedUser);
    if (!userOption) return;
    
    // 检查授权人是否拥有要授予的权限
    const hasAllPermissions = selectedPermissions.every(permission => 
      hasPermission(data.dataType, data.dataId, permission)
    );
    
    if (!hasAllPermissions) {
      setError('您无法授予超过自身权限范围的权限');
      return;
    }

    const grantData = {
      dataId: data.dataId,
      dataType: data.dataType,
      grantorId: currentUser.id,
      granteeId: selectedUser,
      granteeName: userOption.username,
      permissions: selectedPermissions,
      expiresAt: expiresAt || undefined
    };

    const success = await createGrant(grantData);
    if (success) {
      // 刷新授权列表
      const allGrants = getGrants();
      const dataGrants = allGrants.filter(grant => 
        grant.dataId === data.dataId && 
        grant.dataType === data.dataType &&
        grant.status === 'active'
      );
      setGrants(dataGrants);
      
      // 重置表单
      setSelectedUser('');
      setSelectedPermissions([]);
      setExpiresAt('');
    } else {
      setError('授权失败，请检查权限');
    }
  };

  const handleRevokeGrant = async (grantId: string) => {
    const success = await revokeGrant(grantId);
    if (success) {
      setGrants(grants.filter(g => g.id !== grantId));
    }
  };

  const handlePermissionToggle = (permission: 'view' | 'edit' | 'grant') => {
    setSelectedPermissions(prev => 
      prev.includes(permission) 
        ? prev.filter(p => p !== permission)
        : [...prev, permission]
    );
  };

  const handleSave = () => {
    onSave();
    onClose();
  };

  const permissionLabels = {
    view: '查看',
    edit: '编辑',
    grant: '授权'
  };

  const getPermissionColor = (permission: string) => {
    switch (permission) {
      case 'view': return 'bg-blue-100 text-blue-800';
      case 'edit': return 'bg-yellow-100 text-yellow-800';
      case 'grant': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  // 检查用户拥有的权限，只显示可授予的权限选项
  const getAvailablePermissions = (): ('view' | 'edit' | 'grant')[] => {
    if (!data || !currentUser) return [];
    
    const availablePerms: ('view' | 'edit' | 'grant')[] = [];
    
    if (hasPermission(data.dataType, data.dataId, 'view')) {
      availablePerms.push('view');
    }
    if (hasPermission(data.dataType, data.dataId, 'edit')) {
      availablePerms.push('edit');
    }
    if (hasPermission(data.dataType, data.dataId, 'grant')) {
      availablePerms.push('grant');
    }
    
    return availablePerms;
  };

  if (!data) return null;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={`权限配置 - ${data.dataName}`}
      width="max-w-4xl"
      footer={
        <>
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
          >
            取消
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            关闭
          </button>
        </>
      }
    >
      <div className="space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <span className="text-sm text-red-800">{error}</span>
            </div>
          </div>
        )}
        
        {/* 添加授权 */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="font-medium text-gray-900 mb-4 flex items-center">
            <UserPlus className="w-4 h-4 mr-2" />
            添加用户授权
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                选择用户
              </label>
              <select
                value={selectedUser}
                onChange={(e) => setSelectedUser(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">请选择用户</option>
                {availableUsers
                  .filter(user => !grants.some(g => g.granteeId === user.id))
                  .map(user => (
                    <option key={user.id} value={user.id}>
                      {user.username} ({user.email})
                    </option>
                  ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                授权权限
              </label>
              <div className="space-y-2">
                {getAvailablePermissions().map((permission) => (
                  <label key={permission} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={selectedPermissions.includes(permission)}
                      onChange={() => handlePermissionToggle(permission)}
                      className="mr-2 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-sm text-gray-700">
                      {permissionLabels[permission]}
                    </span>
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Calendar className="w-4 h-4 inline mr-1" />
                过期时间（可选）
              </label>
              <input
                type="datetime-local"
                value={expiresAt}
                onChange={(e) => setExpiresAt(e.target.value)}
                min={new Date().toISOString().slice(0, 16)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div className="flex items-end">
              <button
                onClick={handleAddGrant}
                disabled={!selectedUser || selectedPermissions.length === 0}
                className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                <Plus className="w-4 h-4 mr-2" />
                添加授权
              </button>
            </div>
          </div>
        </div>

        {/* 当前授权列表 */}
        <div>
          <h4 className="font-medium text-gray-900 mb-4">当前授权列表</h4>
          {grants.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              暂无授权配置
            </div>
          ) : (
            <div className="space-y-3">
              {grants.map((grant) => (
                <div
                  key={grant.id}
                  className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg"
                >
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-sm font-medium">
                          {grant.granteeName.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{grant.granteeName}</p>
                        <p className="text-sm text-gray-500">
                          授权时间: {new Date(grant.createdAt).toLocaleString()}
                          {grant.expiresAt && (
                            <span className="ml-2">
                              | 过期时间: {new Date(grant.expiresAt).toLocaleString()}
                            </span>
                          )}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="flex flex-wrap gap-1">
                      {grant.permissions.map((permission) => (
                        <span
                          key={permission}
                          className={`px-2 py-1 rounded-full text-xs ${getPermissionColor(permission)}`}
                        >
                          {permissionLabels[permission]}
                        </span>
                      ))}
                    </div>
                    <button
                      onClick={() => handleRevokeGrant(grant.id)}
                      className="p-1 text-red-600 hover:bg-red-50 rounded"
                      title="撤销授权"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
};