import React, { useState } from 'react';
import { Edit, Plus, Shield, Users, Key } from 'lucide-react';
import { Table } from '../Common/Table';
import { Modal } from '../Common/Modal';
import { PermissionModal } from '../Common/PermissionModal';
import { System } from '../../types';
import { useAuth } from '../../hooks/useAuth';

interface SystemListProps {
  onViewProcesses: (systemId: string, systemName: string) => void;
}

export const SystemList: React.FC<SystemListProps> = ({ onViewProcesses }) => {
  const { user, hasPermission, isSuperAdmin, canGrantPermissions, logAuditEvent } = useAuth();
  const [systems, setSystems] = useState<System[]>([
    {
      id: '1',
      name: 'CRM系统',
      description: '客户关系管理系统',
      creatorId: '1',
      apiSecret: 'crm_secret_key_12345',
      createdAt: '2024-01-15',
      status: 'active',
      processCount: 5,
    },
    {
      id: '2',
      name: 'ERP系统',
      description: '企业资源规划系统',
      creatorId: '1',
      apiSecret: 'erp_secret_key_67890',
      createdAt: '2024-01-10',
      status: 'active',
      processCount: 8,
    },
    {
      id: '3',
      name: 'OA系统',
      description: '办公自动化系统',
      creatorId: '2',
      apiSecret: 'oa_secret_key_abcde',
      createdAt: '2024-01-05',
      status: 'inactive',
      processCount: 3,
    }
  ]);

  const [modalOpen, setModalOpen] = useState(false);
  const [permissionModalOpen, setPermissionModalOpen] = useState(false);
  const [editingSystem, setEditingSystem] = useState<System | null>(null);
  const [permissionModalData, setPermissionModalData] = useState<{
    dataType: 'system' | 'process' | 'node';
    dataId: string;
    dataName: string;
  } | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  // Filter systems based on user permissions
  const getVisibleSystems = () => {
    if (isSuperAdmin()) return systems;
    
    return systems.filter(system => 
      hasPermission('system', system.id, 'view') || 
      system.creatorId === user?.id
    );
  };
  
  // 过滤敏感字段
  const filterSensitiveFields = (system: System): System => {
    if (isSuperAdmin() || system.creatorId === user?.id) {
      return system;
    }
    
    // 记录敏感字段访问尝试
    if (system.apiSecret) {
      logAuditEvent('SENSITIVE_FIELD_ACCESS', 'system', system.id, { 
        field: 'apiSecret',
        blocked: true 
      });
    }
    
    const { apiSecret, ...filteredSystem } = system;
    return filteredSystem;
  };

  const columns = [
    {
      key: 'name',
      title: '系统名称',
      width: '20%',
      render: (name: string, record: System) => (
        <div className="flex items-center space-x-2">
          {(hasPermission('system', record.id, 'view') || isSuperAdmin()) ? (
            <button
              onClick={() => onViewProcesses(record.id, record.name)}
              className="text-blue-600 hover:text-blue-800 hover:underline font-medium"
              title="进入流程管理"
            >
              {name}
            </button>
          ) : (
            <span>{name}</span>
          )}
        </div>
      )
    },
    {
      key: 'description',
      title: '描述',
      width: '25%'
    },
    {
      key: 'apiSecret',
      title: 'API密钥',
      width: '15%',
      render: (apiSecret: string, record: System) => {
        const canViewSecret = isSuperAdmin() || record.creatorId === user?.id;
        if (!canViewSecret) {
          return <span className="text-gray-400">***隐藏***</span>;
        }
        return (
          <div className="flex items-center space-x-2">
            <Key className="w-4 h-4 text-gray-400" />
            <code className="text-xs bg-gray-100 px-2 py-1 rounded">
              {apiSecret ? `${apiSecret.substring(0, 8)}...` : '未设置'}
            </code>
          </div>
        );
      }
    },
    {
      key: 'processCount',
      title: '流程数量',
      width: '10%'
    },
    {
      key: 'status',
      title: '状态',
      width: '10%',
      render: (status: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          status === 'active' 
            ? 'bg-green-100 text-green-800' 
            : 'bg-gray-100 text-gray-800'
        }`}>
          {status === 'active' ? '启用' : '禁用'}
        </span>
      )
    },
    {
      key: 'createdAt',
      title: '创建时间',
      width: '10%'
    },
    {
      key: 'actions',
      title: '操作',
      width: '10%',
      render: (_: any, record: System) => (
        <div className="flex space-x-2">
          {(hasPermission('system', record.id, 'edit') || isSuperAdmin()) && (
            <button
              onClick={() => handleEdit(record)}
              className="p-1 text-blue-600 hover:bg-blue-50 rounded"
              title="编辑"
            >
              <Edit className="w-4 h-4" />
            </button>
          )}
          {(canGrantPermissions('system', record.id) || isSuperAdmin()) && (
            <button
              onClick={() => handlePermissionConfig(record)}
              className="p-1 text-purple-600 hover:bg-purple-50 rounded"
              title="权限配置"
            >
              <Shield className="w-4 h-4" />
            </button>
          )}
        </div>
      )
    }
  ];

  const handleEdit = (system: System) => {
    setEditingSystem(system);
    setModalOpen(true);
  };

  const handlePermissionConfig = (system: System) => {
    setPermissionModalData({
      dataType: 'system',
      dataId: system.id,
      dataName: system.name
    });
    setPermissionModalOpen(true);
  };

  const handleDelete = (systemId: string) => {
    if (confirm('确定要删除这个系统吗？')) {
      setSystems(systems.filter(s => s.id !== systemId));
    }
  };

  const handleAdd = () => {
    setEditingSystem(null);
    setModalOpen(true);
  };

  const handlePermissionSave = () => {
    // 权限保存逻辑已在PermissionModal中处理
    setPermissionModalOpen(false);
  };

  const visibleSystems = getVisibleSystems();
  const filteredAndSafeSystems = visibleSystems.map(filterSensitiveFields);
  const filteredSystems = visibleSystems.filter(system =>
    system.name.toLowerCase().includes(searchValue.toLowerCase()) ||
    system.description.toLowerCase().includes(searchValue.toLowerCase())
  ).map(filterSensitiveFields);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">系统管理</h2>
          <p className="text-gray-600 mt-1">
            管理审批流程系统，配置系统权限和流程
          </p>
        </div>
        {isSuperAdmin() && (
          <button
            onClick={handleAdd}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            新增系统
          </button>
        )}
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Shield className="w-5 h-5 text-amber-600 mt-0.5" />
          <div>
            <h4 className="font-medium text-amber-900">权限与安全说明</h4>
            <p className="text-sm text-amber-700 mt-1">
              • 超级管理员拥有所有系统的完整权限，可查看所有敏感信息<br/>
              • 系统创建者拥有该系统的所有权限，包括API密钥查看权限<br/>
              • 被授权用户只能根据授权范围进行操作，敏感字段自动隐藏<br/>
              • 所有敏感字段访问都会记录审计日志
            </p>
          </div>
        </div>
      </div>

      <Table
        columns={columns}
        data={filteredSystems}
        searchable
        searchValue={searchValue}
        onSearch={setSearchValue}
        pagination={{
          current: currentPage,
          total: filteredSystems.length,
          pageSize: 10,
          onChange: setCurrentPage
        }}
      />

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingSystem ? '编辑系统' : '新增系统'}
        footer={
          <>
            <button
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              取消
            </button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
              保存
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              系统名称
            </label>
            <input
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              defaultValue={editingSystem?.name}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              描述
            </label>
            <textarea
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              defaultValue={editingSystem?.description}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              API密钥
            </label>
            <input
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              defaultValue={editingSystem?.apiSecret}
              placeholder="请输入API密钥"
            />
            <p className="text-xs text-gray-500 mt-1">
              API密钥仅创建者和超级管理员可见
            </p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              状态
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              defaultValue={editingSystem?.status}
            >
              <option value="active">启用</option>
              <option value="inactive">禁用</option>
            </select>
          </div>
        </div>
      </Modal>

      <PermissionModal
        open={permissionModalOpen}
        onClose={() => setPermissionModalOpen(false)}
        data={permissionModalData}
        onSave={handlePermissionSave}
      />
    </div>
  );
};