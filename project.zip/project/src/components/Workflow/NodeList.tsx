import React, { useState } from 'react';
import { ArrowLeft, Edit, Plus, Trash2, Settings, Shield, Users } from 'lucide-react';
import { Table } from '../Common/Table';
import { Modal } from '../Common/Modal';
import { PermissionModal } from '../Common/PermissionModal';
import { Node, PermissionModalData } from '../../types';
import { useAuth } from '../../hooks/useAuth';

interface NodeListProps {
  processId: string;
  processName: string;
  onBack: () => void;
}

export const NodeList: React.FC<NodeListProps> = ({
  processId,
  processName,
  onBack
}) => {
  const { user, hasPermission, isSuperAdmin, canGrantPermissions } = useAuth();
  const [nodes, setNodes] = useState<Node[]>([
    {
      id: '1',
      processId,
      name: '开始节点',
      type: 'start',
      order: 1,
      createdBy: '1',
      permissions: []
    },
    {
      id: '2',
      processId,
      name: '部门审批',
      type: 'approval',
      apiUrl: '/api/department/approve',
      parameters: { department: 'finance', timeout: 3600 },
      order: 2,
      createdBy: '1',
      permissions: [
        {
          userId: '2',
          username: 'manager',
          actions: ['view', 'edit'],
          grantedBy: '1',
          grantedAt: '2024-01-15T00:00:00Z'
        }
      ]
    },
    {
      id: '3',
      processId,
      name: '总监审批',
      type: 'approval',
      apiUrl: '/api/director/approve',
      parameters: { level: 'director', autoApprove: false },
      order: 3,
      createdBy: '2',
      permissions: []
    },
    {
      id: '4',
      processId,
      name: '结束节点',
      type: 'end',
      order: 4,
      createdBy: '1',
      permissions: []
    }
  ]);

  const [modalOpen, setModalOpen] = useState(false);
  const [permissionModalOpen, setPermissionModalOpen] = useState(false);
  const [editingNode, setEditingNode] = useState<Node | null>(null);
  const [permissionModalData, setPermissionModalData] = useState<PermissionModalData | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  // Filter nodes based on user permissions
  const getVisibleNodes = () => {
    if (isSuperAdmin()) return nodes;
    
    return nodes.filter(node => 
      hasPermission('node', node.id, 'view') || 
      node.createdBy === user?.id ||
      hasPermission('process', processId, 'view')
    );
  };

  const columns = [
    {
      key: 'order',
      title: '序号',
      width: '8%'
    },
    {
      key: 'name',
      title: '节点名称',
      width: '20%'
    },
    {
      key: 'type',
      title: '节点类型',
      width: '12%',
      render: (type: string) => {
        const typeMap = {
          start: '开始',
          approval: '审批',
          notification: '通知',
          end: '结束'
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs ${
            type === 'start' ? 'bg-green-100 text-green-800' :
            type === 'approval' ? 'bg-blue-100 text-blue-800' :
            type === 'notification' ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }`}>
            {typeMap[type as keyof typeof typeMap]}
          </span>
        );
      }
    },
    {
      key: 'apiUrl',
      title: 'API地址',
      width: '25%',
      render: (apiUrl: string) => (
        <span className="text-sm font-mono text-gray-600">
          {apiUrl || '-'}
        </span>
      )
    },
    {
      key: 'permissions',
      title: '授权用户',
      width: '10%',
      render: (permissions: any[]) => (
        <div className="flex items-center space-x-1">
          <Users className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-600">
            {permissions.length} 人
          </span>
        </div>
      )
    },
    {
      key: 'actions',
      title: '操作',
      width: '25%',
      render: (_: any, record: Node) => (
        <div className="flex space-x-2">
          {(hasPermission('node', record.id, 'edit') || isSuperAdmin()) && (
            <button
              onClick={() => handleEdit(record)}
              className="p-1 text-blue-600 hover:bg-blue-50 rounded"
              title="编辑"
            >
              <Edit className="w-4 h-4" />
            </button>
          )}
          {(canGrantPermissions('node', record.id) || isSuperAdmin()) && (
            <button
              onClick={() => handlePermissionConfig(record)}
              className="p-1 text-purple-600 hover:bg-purple-50 rounded"
              title="权限配置"
            >
              <Shield className="w-4 h-4" />
            </button>
          )}
          {(hasPermission('node', record.id, 'edit') || isSuperAdmin()) && (
            <button
              onClick={() => handleConfigParams(record)}
              className="p-1 text-green-600 hover:bg-green-50 rounded"
              title="参数配置"
            >
              <Settings className="w-4 h-4" />
            </button>
          )}
          {(hasPermission('node', record.id, 'delete') || isSuperAdmin()) && (
            <button
              onClick={() => handleDelete(record.id)}
              className="p-1 text-red-600 hover:bg-red-50 rounded"
              title="删除"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      )
    }
  ];

  const handleEdit = (node: Node) => {
    setEditingNode(node);
    setModalOpen(true);
  };

  const handlePermissionConfig = (node: Node) => {
    setPermissionModalData({
      resourceType: 'node',
      resourceId: node.id,
      resourceName: node.name,
      currentPermissions: node.permissions
    });
    setPermissionModalOpen(true);
  };

  const handleConfigParams = (node: Node) => {
    // 参数配置逻辑
    console.log('配置参数:', node);
  };

  const handleDelete = (nodeId: string) => {
    if (confirm('确定要删除这个节点吗？')) {
      setNodes(nodes.filter(n => n.id !== nodeId));
    }
  };

  const handleAdd = () => {
    setEditingNode(null);
    setModalOpen(true);
  };

  const handlePermissionSave = (permissions: any[]) => {
    if (!permissionModalData) return;
    
    setNodes(nodes.map(node => 
      node.id === permissionModalData.resourceId
        ? { ...node, permissions }
        : node
    ));
  };

  const visibleNodes = getVisibleNodes();
  const filteredNodes = visibleNodes.filter(node =>
    node.name.toLowerCase().includes(searchValue.toLowerCase())
  );

  const canCreateNode = hasPermission('process', processId, 'edit') || isSuperAdmin();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={onBack}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">节点管理</h2>
            <p className="text-gray-600">流程：{processName}</p>
          </div>
        </div>
        {canCreateNode && (
          <button
            onClick={handleAdd}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            新增节点
          </button>
        )}
      </div>

      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Settings className="w-5 h-5 text-green-600 mt-0.5" />
          <div>
            <h4 className="font-medium text-green-900">节点配置说明</h4>
            <p className="text-sm text-green-700 mt-1">
              • 节点支持独立的权限配置，可精确控制访问权限
              • API配置支持动态参数，可根据业务需求灵活调整
              • 节点顺序决定审批流程的执行顺序
            </p>
          </div>
        </div>
      </div>

      <Table
        columns={columns}
        data={filteredNodes}
        searchable
        searchValue={searchValue}
        onSearch={setSearchValue}
        pagination={{
          current: currentPage,
          total: filteredNodes.length,
          pageSize: 10,
          onChange: setCurrentPage
        }}
      />

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingNode ? '编辑节点' : '新增节点'}
        width="max-w-2xl"
        footer={
          <>
            <button
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              取消
            </button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
              保存
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                节点名称
              </label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                defaultValue={editingNode?.name}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                节点类型
              </label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                defaultValue={editingNode?.type}
              >
                <option value="start">开始</option>
                <option value="approval">审批</option>
                <option value="notification">通知</option>
                <option value="end">结束</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              API地址
            </label>
            <input
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              defaultValue={editingNode?.apiUrl}
              placeholder="/api/approval/endpoint"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              参数配置
            </label>
            <textarea
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder='{"参数名": "参数值"}'
              defaultValue={editingNode?.parameters ? JSON.stringify(editingNode.parameters, null, 2) : ''}
            />
            <p className="text-xs text-gray-500 mt-1">
              请输入有效的JSON格式参数配置
            </p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              排序
            </label>
            <input
              type="number"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              defaultValue={editingNode?.order}
              min={1}
            />
          </div>
        </div>
      </Modal>

      <PermissionModal
        open={permissionModalOpen}
        onClose={() => setPermissionModalOpen(false)}
        data={permissionModalData}
        onSave={handlePermissionSave}
      />
    </div>
  );
};