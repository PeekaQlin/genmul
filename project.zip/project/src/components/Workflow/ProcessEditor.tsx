import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Edit,
  CheckCircle,
  XCircle,
  Save,
  TestTube,
  AlertTriangle,
  Copy,
  Plus,
  Trash2,
  Settings,
  Eye,
  EyeOff,
  Globe,
  DollarSign,
  User,
  Building,
  Phone,
  Mail,
  Calendar,
  Hash,
  Type,
  ChevronDown,
  ChevronRight,
  MousePointer,
  Layers,
  Layout,
  FileText,
  Clock,
  UserCheck,
  Table
} from 'lucide-react';
import { Modal } from '../Common/Modal';

interface ProcessEditorProps {
  processId: string;
  processName: string;
  onBack: () => void;
}

interface FormField {
  id: string;
  type: 'text' | 'number' | 'date' | 'amount' | 'name' | 'department' | 'country' | 'phone' | 'email';
  label: string;
  required: boolean;
  placeholder?: string;
  unit?: string;
  masked: boolean;
  sectionId?: string;
  visibleUsers?: string[];
}

interface FormSection {
  id: string;
  title: string;
  collapsed: boolean;
  fields: string[];
}

interface FormButton {
  id: string;
  type: 'approve' | 'reject' | 'return' | 'transfer' | 'countersign' | 'remind';
  label: string;
  apiUrl: string;
  testStatus: 'idle' | 'testing' | 'success' | 'error';
  testMessage?: string;
}

interface FormVersion {
  id: string;
  name: string;
  createdAt: string;
  formId: string;
  status: 'draft' | 'published' | 'archived';
  description?: string;
}

interface FormListItem {
  id: string;
  name: string;
  formId: string;
  createdAt: string;
  updatedAt: string;
  status: 'draft' | 'published' | 'archived';
  description?: string;
  fieldCount: number;
  versionName?: string;
}

export const ProcessEditor: React.FC<ProcessEditorProps> = ({
  processId,
  processName,
  onBack
}) => {
  const [editableProcessName, setEditableProcessName] = useState(processName);
  const [isEditingName, setIsEditingName] = useState(false);
  
  // 对接模式：'redirect' | 'form'
  const [integrationMode, setIntegrationMode] = useState<'redirect' | 'form'>('form');
  
  // 表单列表和编辑状态
  const [showFormList, setShowFormList] = useState(true);
  const [editingFormId, setEditingFormId] = useState<string | null>(null);
  
  // 表单配置状态
  const [formConfig, setFormConfig] = useState({
    title: '合同审批申请',
    flowNumber: 'SP202412010001',
    applicant: '张三',
    department: '技术部',
    email: 'zhangsan@company.com',
    applyTime: '2024-12-01 14:30:25'
  });

  // 跳转模式配置
  const [redirectUrl, setRedirectUrl] = useState('');
  const [redirectTestStatus, setRedirectTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [redirectTestMessage, setRedirectTestMessage] = useState('');
  
  // 表单列表数据
  const [formList, setFormList] = useState<FormListItem[]>([
    {
      id: 'form1',
      name: '合同审批表单',
      formId: 'FORM_20241201_001',
      createdAt: '2024-12-01 10:30:00',
      updatedAt: '2024-12-01 15:20:00',
      status: 'published',
      description: '用于合同审批流程的标准表单',
      fieldCount: 8
    },
    {
      id: 'form2',
      name: '费用报销表单',
      versionName: '草稿',
      formId: 'FORM_20241201_002',
      createdAt: '2024-12-01 14:15:00',
      updatedAt: '2024-12-01 16:45:00',
      status: 'draft',
      description: '员工费用报销申请表单',
      fieldCount: 6
    },
    {
      id: 'form3',
      name: '请假申请表单',
      versionName: '已归档',
      formId: 'FORM_20241130_003',
      createdAt: '2024-11-30 09:20:00',
      updatedAt: '2024-11-30 11:30:00',
      status: 'archived',
      description: '员工请假申请专用表单',
      fieldCount: 5
    }
  ]);
  
  // 表单设计器状态
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);
  const [formFields, setFormFields] = useState<FormField[]>([
    {
      id: 'field1',
      type: 'text',
      label: '申请标题',
      required: true,
      placeholder: '请输入申请标题',
      masked: false,
      visibleUsers: []
    },
    {
      id: 'field2',
      type: 'amount',
      label: '申请金额',
      required: true,
      unit: '元',
      masked: true,
      sectionId: 'section1',
      visibleUsers: ['张三', '李四']
    },
    {
      id: 'field3',
      type: 'name',
      label: '申请人',
      required: true,
      masked: false,
      sectionId: 'section1',
      visibleUsers: []
    }
  ]);
  
  const [formSections, setFormSections] = useState<FormSection[]>([
    {
      id: 'section1',
      title: '基本信息',
      collapsed: false,
      fields: ['field2', 'field3']
    }
  ]);
  
  const [formButtons, setFormButtons] = useState<FormButton[]>([
    {
      id: 'btn1',
      type: 'approve',
      label: '通过',
      apiUrl: '',
      testStatus: 'idle'
    },
    {
      id: 'btn2',
      type: 'reject',
      label: '驳回',
      apiUrl: '',
      testStatus: 'idle'
    },
    {
      id: 'btn3',
      type: 'return',
      label: '回退',
      apiUrl: '',
      testStatus: 'idle'
    },
    {
      id: 'btn4',
      type: 'transfer',
      label: '转交',
      apiUrl: '',
      testStatus: 'idle'
    }
  ]);
  
  const [formVersions, setFormVersions] = useState<FormVersion[]>([
    {
      id: 'v1',
      name: '版本 1.0',
      createdAt: '2024-01-15 10:30:00',
      formId: 'FORM_20240115_001',
      status: 'published',
      description: '初始版本'
    }
  ]);
  
  const [currentFormId] = useState('FORM_20240115_001');
  const [showVersionModal, setShowVersionModal] = useState(false);
  const [editingVersionName, setEditingVersionName] = useState<string | null>(null);
  const [tempVersionName, setTempVersionName] = useState('');

  // 处理流程名称编辑
  const handleNameSave = () => {
    setIsEditingName(false);
    console.log('保存流程名称:', editableProcessName);
  };

  const handleNameCancel = () => {
    setEditableProcessName(processName);
    setIsEditingName(false);
  };

  // 处理跳转地址测试
  const handleRedirectTest = async () => {
    if (!redirectUrl.trim()) {
      setRedirectTestMessage('请先填写跳转地址');
      setRedirectTestStatus('error');
      return;
    }

    setRedirectTestStatus('testing');
    setRedirectTestMessage('正在测试连接...');

    // 模拟测试
    setTimeout(() => {
      try {
        new URL(redirectUrl);
        setRedirectTestStatus('success');
        setRedirectTestMessage('连接测试成功');
      } catch {
        setRedirectTestStatus('error');
        setRedirectTestMessage('URL格式不正确');
      }
    }, 2000);
  };

  // 处理按钮接口测试
  const handleButtonTest = async (buttonId: string) => {
    const button = formButtons.find(b => b.id === buttonId);
    if (!button || !button.apiUrl.trim()) return;

    setFormButtons(prev => prev.map(b => 
      b.id === buttonId 
        ? { ...b, testStatus: 'testing', testMessage: '正在测试连接...' }
        : b
    ));

    // 模拟测试
    setTimeout(() => {
      try {
        new URL(button.apiUrl);
        setFormButtons(prev => prev.map(b => 
          b.id === buttonId 
            ? { ...b, testStatus: 'success', testMessage: '接口连接成功' }
            : b
        ));
      } catch {
        setFormButtons(prev => prev.map(b => 
          b.id === buttonId 
            ? { ...b, testStatus: 'error', testMessage: 'URL格式不正确' }
            : b
        ));
      }
    }, 1500);
  };

  // 复制表单ID
  const handleCopyFormId = () => {
    navigator.clipboard.writeText(currentFormId);
    // 这里可以添加复制成功的提示
  };

  // 处理表单列表操作
  const handleCreateForm = () => {
    const newForm: FormListItem = {
      id: `form_${Date.now()}`,
      name: '新建表单',
      versionName: '草稿',
      formId: `FORM_${new Date().toISOString().slice(0, 10).replace(/-/g, '')}_${String(formList.length + 1).padStart(3, '0')}`,
      createdAt: new Date().toLocaleString(),
      updatedAt: new Date().toLocaleString(),
      status: 'draft',
      description: '',
      fieldCount: 0
    };
    setFormList(prev => [...prev, newForm]);
    setEditingFormId(newForm.id);
    setShowFormList(false);
  };

  const handleEditForm = (formId: string) => {
    setEditingFormId(formId);
    setShowFormList(false);
  };

  const handleBackToFormList = () => {
    setEditingFormId(null);
    setShowFormList(true);
  };

  const handleDeleteForm = (formId: string) => {
    if (confirm('确定要删除这个表单吗？')) {
      setFormList(prev => prev.filter(f => f.id !== formId));
    }
  };

  const handleVersionNameEdit = (formId: string, currentName: string) => {
    setEditingVersionName(formId);
    setTempVersionName(currentName);
  };

  const handleVersionNameSave = (formId: string) => {
    setFormList(prev => prev.map(form => 
      form.id === formId 
        ? { ...form, versionName: tempVersionName, updatedAt: new Date().toLocaleString() }
        : form
    ));
    setEditingVersionName(null);
    setTempVersionName('');
  };

  const handleVersionNameCancel = () => {
    setEditingVersionName(null);
    setTempVersionName('');
  };
  // 添加字段
  const handleAddField = (type: FormField['type']) => {
    const newField: FormField = {
      id: `field_${Date.now()}`,
      type,
      label: getFieldTypeLabel(type),
      required: false,
      masked: ['amount', 'name', 'phone', 'email'].includes(type),
      visibleUsers: [],
      ...(type === 'amount' && { unit: '元' })
    };
    
    setFormFields(prev => [...prev, newField]);
    setSelectedComponent(newField.id);
  };

  // 添加分区
  const handleAddSection = () => {
    const newSection: FormSection = {
      id: `section_${Date.now()}`,
      title: '新分区',
      collapsed: false,
      fields: []
    };
    
    setFormSections(prev => [...prev, newSection]);
    setSelectedComponent(newSection.id);
  };

  // 获取字段类型标签
  const getFieldTypeLabel = (type: FormField['type']) => {
    const labels = {
      text: '文本字段',
      number: '数字字段',
      date: '日期字段',
      amount: '金额字段',
      name: '姓名字段',
      department: '部门字段',
      country: '国家字段',
      phone: '手机号字段',
      email: '邮箱字段'
    };
    return labels[type];
  };

  // 获取字段类型图标
  const getFieldTypeIcon = (type: FormField['type']) => {
    const icons = {
      text: <Type className="w-4 h-4" />,
      number: <Hash className="w-4 h-4" />,
      date: <Calendar className="w-4 h-4" />,
      amount: <DollarSign className="w-4 h-4" />,
      name: <User className="w-4 h-4" />,
      department: <Building className="w-4 h-4" />,
      country: <Globe className="w-4 h-4" />,
      phone: <Phone className="w-4 h-4" />,
      email: <Mail className="w-4 h-4" />
    };
    return icons[type];
  };

  // 渲染字段预览
  const renderFieldPreview = (field: FormField) => {
    const displayValue = field.masked ? '****' : 
      field.type === 'amount' ? `1000${field.unit || ''}` :
      field.type === 'name' ? '张三' :
      field.type === 'department' ? '技术部' :
      field.type === 'country' ? '中国' :
      field.type === 'phone' ? '138****8888' :
      field.type === 'email' ? 'user@example.com' :
      field.type === 'date' ? '2024-01-15' :
      '示例内容';

    return (
      <div
        key={field.id}
        className={`p-3 border rounded-lg cursor-pointer transition-colors ${
          selectedComponent === field.id 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-200 hover:border-gray-300'
        }`}
        onClick={() => setSelectedComponent(field.id)}
      >
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            {getFieldTypeIcon(field.type)}
            <span className="font-medium text-sm">{field.label}</span>
            {field.required && <span className="text-red-500 text-xs">*</span>}
            {field.masked && <EyeOff className="w-3 h-3 text-gray-400" />}
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setFormFields(prev => prev.filter(f => f.id !== field.id));
            }}
            className="text-red-500 hover:text-red-700"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
        <div className="text-sm text-gray-600 bg-gray-50 p-2 rounded">
          {displayValue}
        </div>
      </div>
    );
  };

  // 渲染分区预览
  const renderSectionPreview = (section: FormSection) => {
    const sectionFields = formFields.filter(f => f.sectionId === section.id);
    
    return (
      <div
        key={section.id}
        className={`border rounded-lg transition-colors ${
          selectedComponent === section.id 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-200'
        }`}
      >
        <div
          className="flex items-center justify-between p-3 cursor-pointer"
          onClick={() => setSelectedComponent(section.id)}
        >
          <div className="flex items-center space-x-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setFormSections(prev => prev.map(s => 
                  s.id === section.id ? { ...s, collapsed: !s.collapsed } : s
                ));
              }}
            >
              {section.collapsed ? 
                <ChevronRight className="w-4 h-4" /> : 
                <ChevronDown className="w-4 h-4" />
              }
            </button>
            <Layers className="w-4 h-4" />
            <span className="font-medium">{section.title}</span>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setFormSections(prev => prev.filter(s => s.id !== section.id));
              setFormFields(prev => prev.map(f => 
                f.sectionId === section.id ? { ...f, sectionId: undefined } : f
              ));
            }}
            className="text-red-500 hover:text-red-700"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
        
        {!section.collapsed && (
          <div className="px-3 pb-3 space-y-2">
            {sectionFields.map(field => renderFieldPreview(field))}
            {sectionFields.length === 0 && (
              <div className="text-center text-gray-400 py-4 border-2 border-dashed border-gray-200 rounded">
                拖拽字段到此分区
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  // 渲染属性配置面板
  const renderPropertyPanel = () => {
    if (!selectedComponent) {
      return (
        <div className="text-center text-gray-500 py-8">
          <MousePointer className="w-8 h-8 mx-auto mb-2 text-gray-400" />
          <p>点击组件查看属性配置</p>
        </div>
      );
    }

    // 表单配置
    if (selectedComponent === 'form-config') {
      return (
        <div className="space-y-4">
          <h3 className="font-medium text-gray-900">表单配置</h3>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">表单标题</label>
            <input
              type="text"
              value={formConfig.title}
              onChange={(e) => setFormConfig(prev => ({ ...prev, title: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">流程单号</label>
            <input
              type="text"
              value={formConfig.flowNumber}
              onChange={(e) => setFormConfig(prev => ({ ...prev, flowNumber: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">申请人</label>
            <input
              type="text"
              value={formConfig.applicant}
              onChange={(e) => setFormConfig(prev => ({ ...prev, applicant: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">所属部门</label>
            <input
              type="text"
              value={formConfig.department}
              onChange={(e) => setFormConfig(prev => ({ ...prev, department: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">联系邮箱</label>
            <input
              type="email"
              value={formConfig.email}
              onChange={(e) => setFormConfig(prev => ({ ...prev, email: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">申请时间</label>
            <input
              type="datetime-local"
              value={formConfig.applyTime.replace(' ', 'T')}
              onChange={(e) => setFormConfig(prev => ({ ...prev, applyTime: e.target.value.replace('T', ' ') }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
      );
    }

    const selectedField = formFields.find(f => f.id === selectedComponent);
    const selectedSection = formSections.find(s => s.id === selectedComponent);

    if (selectedField) {
      return (
        <div className="space-y-4">
          <h3 className="font-medium text-gray-900">字段属性</h3>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">字段标签</label>
            <input
              type="text"
              value={selectedField.label}
              onChange={(e) => setFormFields(prev => prev.map(f => 
                f.id === selectedField.id ? { ...f, label: e.target.value } : f
              ))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">字段类型</label>
            <input
              type="text"
              value={getFieldTypeLabel(selectedField.type)}
              readOnly
              className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">占位符</label>
            <input
              type="text"
              value={selectedField.placeholder || ''}
              onChange={(e) => setFormFields(prev => prev.map(f => 
                f.id === selectedField.id ? { ...f, placeholder: e.target.value } : f
              ))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={selectedField.required}
              onChange={(e) => setFormFields(prev => prev.map(f => 
                f.id === selectedField.id ? { ...f, required: e.target.checked } : f
              ))}
              className="rounded border-gray-300"
            />
            <label className="text-sm text-gray-700">必填字段</label>
          </div>
          
          {selectedField.type === 'amount' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">单位</label>
              <input
                type="text"
                value={selectedField.unit || ''}
                onChange={(e) => setFormFields(prev => prev.map(f => 
                  f.id === selectedField.id ? { ...f, unit: e.target.value } : f
                ))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          )}
          
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={selectedField.masked}
              onChange={(e) => setFormFields(prev => prev.map(f => 
                f.id === selectedField.id ? { ...f, masked: e.target.checked } : f
              ))}
              className="rounded border-gray-300"
            />
            <label className="text-sm text-gray-700">脱敏显示</label>
          </div>
          
          {selectedField.masked && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">可见人员配置</label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    placeholder="输入人员姓名"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        const input = e.target as HTMLInputElement;
                        const name = input.value.trim();
                        if (name && !selectedField.visibleUsers?.includes(name)) {
                          setFormFields(prev => prev.map(f => 
                            f.id === selectedField.id 
                              ? { ...f, visibleUsers: [...(f.visibleUsers || []), name] }
                              : f
                          ));
                          input.value = '';
                        }
                      }
                    }}
                  />
                  <button
                    onClick={(e) => {
                      const input = (e.target as HTMLButtonElement).previousElementSibling as HTMLInputElement;
                      const name = input.value.trim();
                      if (name && !selectedField.visibleUsers?.includes(name)) {
                        setFormFields(prev => prev.map(f => 
                          f.id === selectedField.id 
                            ? { ...f, visibleUsers: [...(f.visibleUsers || []), name] }
                            : f
                        ));
                        input.value = '';
                      }
                    }}
                    className="px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="space-y-1">
                  {selectedField.visibleUsers?.map((user, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-50 px-3 py-2 rounded">
                      <span className="text-sm">{user}</span>
                      <button
                        onClick={() => setFormFields(prev => prev.map(f => 
                          f.id === selectedField.id 
                            ? { ...f, visibleUsers: f.visibleUsers?.filter((_, i) => i !== index) }
                            : f
                        ))}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
                
                {(!selectedField.visibleUsers || selectedField.visibleUsers.length === 0) && (
                  <p className="text-xs text-gray-500">暂无可见人员，所有人都无法查看此字段内容</p>
                )}
              </div>
            </div>
          )}
        </div>
      );
    }

    if (selectedSection) {
      return (
        <div className="space-y-4">
          <h3 className="font-medium text-gray-900">分区属性</h3>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">分区标题</label>
            <input
              type="text"
              value={selectedSection.title}
              onChange={(e) => setFormSections(prev => prev.map(s => 
                s.id === selectedSection.id ? { ...s, title: e.target.value } : s
              ))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={selectedSection.collapsed}
              onChange={(e) => setFormSections(prev => prev.map(s => 
                s.id === selectedSection.id ? { ...s, collapsed: e.target.checked } : s
              ))}
              className="rounded border-gray-300"
            />
            <label className="text-sm text-gray-700">默认折叠</label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">包含字段</label>
            <div className="text-sm text-gray-600">
              {selectedSection.fields.length} 个字段
            </div>
          </div>
        </div>
      );
    }

    return null;
  };

  // 渲染表单列表
  const renderFormList = () => {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-medium text-gray-900">表单列表</h3>
            <p className="text-sm text-gray-600 mt-1">管理流程中使用的表单模板</p>
          </div>
          <button
            onClick={handleCreateForm}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            新建表单
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {formList.map(form => (
            <div key={form.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900 mb-1">{form.name}</h4>
                  <div className="mb-2">
                    {editingVersionName === form.id ? (
                      <div className="flex items-center space-x-2">
                        <input
                          type="text"
                          value={tempVersionName}
                          onChange={(e) => setTempVersionName(e.target.value)}
                          className="text-sm px-2 py-1 border border-blue-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                          autoFocus
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              handleVersionNameSave(form.id);
                            } else if (e.key === 'Escape') {
                              handleVersionNameCancel();
                            }
                          }}
                        />
                        <button
                          onClick={() => handleVersionNameSave(form.id)}
                          className="p-1 text-green-600 hover:bg-green-50 rounded"
                          title="保存"
                        >
                          <CheckCircle className="w-3 h-3" />
                        </button>
                        <button
                          onClick={handleVersionNameCancel}
                          className="p-1 text-red-600 hover:bg-red-50 rounded"
                          title="取消"
                        >
                          <XCircle className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-blue-600 font-medium">{form.versionName}</span>
                        <button
                          onClick={() => handleVersionNameEdit(form.id, form.versionName || '')}
                          className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"
                          title="编辑版本名称"
                        >
                          <Edit className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-gray-500 mb-2">{form.description || '暂无描述'}</p>
                  <div className="flex items-center space-x-4 text-xs text-gray-400">
                    <span>ID: {form.formId}</span>
                    <span>{form.fieldCount} 个字段</span>
                  </div>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs ${
                  form.status === 'published' ? 'bg-green-100 text-green-800' :
                  form.status === 'draft' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {form.status === 'published' ? '已发布' : 
                   form.status === 'draft' ? '草稿' : '已归档'}
                </span>
              </div>
              
              <div className="text-xs text-gray-500 mb-4">
                <div>创建时间: {form.createdAt}</div>
                <div>更新时间: {form.updatedAt}</div>
              </div>
              
              <div className="flex items-center justify-between">
                <button
                  onClick={() => handleEditForm(form.id)}
                  className="inline-flex items-center px-3 py-1.5 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition-colors"
                >
                  <Edit className="w-3 h-3 mr-1" />
                  编辑
                </button>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => {/* 预览功能 */}}
                    className="p-1.5 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded"
                    title="预览"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteForm(form.id)}
                    className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded"
                    title="删除"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // 渲染表单预览头部
  const renderFormPreviewHeader = () => {
    return (
      <div className="bg-white border-b border-gray-200 p-6">
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-gray-900">{formConfig.title}</h2>
        </div>
        
        <div className="space-y-4 text-sm">
          <div className="flex items-center space-x-3">
            <FileText className="w-4 h-4 text-gray-500" />
            <span className="text-gray-600">流程单号:</span>
            <span className="font-mono text-gray-900">{formConfig.flowNumber}</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <User className="w-4 h-4 text-gray-500" />
            <span className="text-gray-600">申请人:</span>
            <span className="text-gray-900">{formConfig.applicant}</span>
            <Building className="w-4 h-4 text-gray-500 ml-4" />
            <span className="text-gray-600">所属部门:</span>
            <span className="text-gray-900">{formConfig.department}</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <Clock className="w-4 h-4 text-gray-500" />
            <span className="text-gray-600">申请时间:</span>
            <span className="text-gray-900">{formConfig.applyTime}</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <Settings className="w-4 h-4 text-gray-500" />
            <span className="text-gray-600">来源系统:</span>
            <span className="text-gray-900">审批管理系统</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* 页面标题区 */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={showFormList && integrationMode === 'form' ? handleBackToFormList : onBack}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-medium text-gray-700">流程配置</h2>
              <span className="text-gray-400">|</span>
              {isEditingName ? (
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={editableProcessName}
                    onChange={(e) => setEditableProcessName(e.target.value)}
                    className="text-2xl font-bold text-gray-900 bg-transparent border-b-2 border-blue-500 focus:outline-none"
                    autoFocus
                    onKeyPress={(e) => e.key === 'Enter' && handleNameSave()}
                  />
                  <button
                    onClick={handleNameSave}
                    className="p-1 text-green-600 hover:bg-green-50 rounded"
                    title="保存"
                  >
                    <CheckCircle className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleNameCancel}
                    className="p-1 text-red-600 hover:bg-red-50 rounded"
                    title="取消"
                  >
                    <XCircle className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <h1 className="text-2xl font-bold text-gray-900">{editableProcessName}</h1>
                  <button
                    onClick={() => setIsEditingName(true)}
                    className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"
                    title="编辑流程名称"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <span className="text-sm text-gray-500">流程ID: {processId}</span>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <Save className="w-4 h-4 inline mr-2" />
            保存配置
          </button>
        </div>
      </div>

      {/* 对接模式选择 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">对接模式选择</h3>
        
        <div className="space-y-4">
          <div className="flex space-x-6">
            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="radio"
                name="integrationMode"
                value="redirect"
                checked={integrationMode === 'redirect'}
                onChange={(e) => {
                  setIntegrationMode(e.target.value as 'redirect');
                  setShowFormList(false);
                }}
                className="text-blue-600"
              />
              <span className="font-medium">跳转系统页面</span>
            </label>
            
            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="radio"
                name="integrationMode"
                value="form"
                checked={integrationMode === 'form'}
                onChange={(e) => {
                  setIntegrationMode(e.target.value as 'form');
                  setShowFormList(true);
                  setEditingFormId(null);
                }}
                className="text-blue-600"
              />
              <span className="font-medium">使用审批中心页面</span>
            </label>
          </div>

          {integrationMode === 'redirect' && (
            <div className="bg-gray-50 rounded-lg p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  跳转页面地址 <span className="text-red-500">*</span>
                </label>
                <input
                  type="url"
                  value={redirectUrl}
                  onChange={(e) => setRedirectUrl(e.target.value)}
                  placeholder="http://example.com/page?param1=value1&data=xxx"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
                <p className="text-xs text-gray-500 mt-1">
                  支持标准URL格式，可包含查询参数
                </p>
              </div>
              
              <div className="flex items-center space-x-4">
                <button
                  onClick={handleRedirectTest}
                  disabled={redirectTestStatus === 'testing'}
                  className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  <TestTube className="w-4 h-4 mr-2" />
                  {redirectTestStatus === 'testing' ? '测试中...' : '测试连接'}
                </button>
                
                {redirectTestStatus !== 'idle' && (
                  <div className={`flex items-center space-x-2 ${
                    redirectTestStatus === 'success' ? 'text-green-600' :
                    redirectTestStatus === 'error' ? 'text-red-600' :
                    'text-blue-600'
                  }`}>
                    {redirectTestStatus === 'success' && <CheckCircle className="w-4 h-4" />}
                    {redirectTestStatus === 'error' && <XCircle className="w-4 h-4" />}
                    {redirectTestStatus === 'testing' && <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />}
                    <span className="text-sm">{redirectTestMessage}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {integrationMode === 'form' && showFormList && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-900">表单设计器已激活</h4>
                  <p className="text-sm text-blue-700 mt-1">
                    您可以创建新表单或编辑现有表单，配置字段属性和按钮操作
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 表单列表（仅在使用审批中心页面模式且显示列表时显示） */}
      {integrationMode === 'form' && showFormList && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          {renderFormList()}
        </div>
      )}

      {/* 表单设计器（仅在使用审批中心页面模式且编辑表单时显示） */}
      {integrationMode === 'form' && !showFormList && editingFormId && (
        <>
          {/* 表单ID和版本管理 */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900">表单版本管理</h3>
              <button
                onClick={() => setShowVersionModal(true)}
                className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                版本历史
              </button>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <span className="text-sm font-medium text-gray-700">当前表单ID:</span>
                <code className="px-2 py-1 bg-gray-100 rounded text-sm font-mono">{currentFormId}</code>
                <button
                  onClick={handleCopyFormId}
                  className="p-1 text-gray-500 hover:text-gray-700"
                  title="复制表单ID"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* 表单设计器主界面 */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">表单设计器</h3>
            
            <div className="grid grid-cols-12 gap-6">
              {/* 组件库 */}
              <div className="col-span-3">
                <h4 className="font-medium text-gray-900 mb-3">组件库</h4>
                
                <div className="space-y-4">
                  {/* 表单字段 */}
                  <div>
                    <h5 className="text-sm font-medium text-gray-700 mb-2">表单字段</h5>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { type: 'text' as const, label: '文本', icon: <Type className="w-4 h-4" /> },
                        { type: 'number' as const, label: '数字', icon: <Hash className="w-4 h-4" /> },
                        { type: 'date' as const, label: '日期', icon: <Calendar className="w-4 h-4" /> },
                        { type: 'amount' as const, label: '金额', icon: <DollarSign className="w-4 h-4" /> },
                        { type: 'name' as const, label: '姓名', icon: <User className="w-4 h-4" /> },
                        { type: 'department' as const, label: '部门', icon: <Building className="w-4 h-4" /> },
                        { type: 'country' as const, label: '国家', icon: <Globe className="w-4 h-4" /> },
                        { type: 'phone' as const, label: '手机', icon: <Phone className="w-4 h-4" /> },
                        { type: 'email' as const, label: '邮箱', icon: <Mail className="w-4 h-4" /> }
                      ].map((fieldType) => (
                        <button
                          key={fieldType.type}
                          onClick={() => handleAddField(fieldType.type)}
                          className="flex items-center space-x-2 p-2 border border-gray-200 rounded hover:bg-gray-50 text-sm"
                        >
                          {fieldType.icon}
                          <span>{fieldType.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 布局组件 */}
                  <div>
                    <h5 className="text-sm font-medium text-gray-700 mb-2">布局组件</h5>
                    <div className="space-y-2">
                      <button
                        onClick={handleAddSection}
                        className="w-full flex items-center space-x-2 p-2 border border-gray-200 rounded hover:bg-gray-50 text-sm"
                      >
                        <Layers className="w-4 h-4" />
                        <span>分区容器</span>
                      </button>
                      <button
                        onClick={() => {/* 添加表格 */}}
                        className="w-full flex items-center space-x-2 p-2 border border-gray-200 rounded hover:bg-gray-50 text-sm"
                      >
                        <Table className="w-4 h-4" />
                        <span>表格组件</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* 表单预览区 */}
              <div className="col-span-6">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium text-gray-900">表单预览</h4>
                  <button className="inline-flex items-center px-3 py-1 text-sm border border-gray-300 rounded hover:bg-gray-50">
                    <Eye className="w-4 h-4 mr-1" />
                    预览
                  </button>
                </div>
                
                <div className="border border-gray-200 rounded-lg min-h-96">
                  {/* 表单预览头部 */}
                  <div 
                    className="cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => setSelectedComponent('form-config')}
                  >
                    {renderFormPreviewHeader()}
                  </div>
                  
                  <div className="p-4 space-y-4">
                    {/* 独立字段 */}
                    {formFields.filter(f => !f.sectionId).map(field => renderFieldPreview(field))}
                    
                    {/* 分区 */}
                    {formSections.map(section => renderSectionPreview(section))}
                    
                    {formFields.length === 0 && formSections.length === 0 && (
                      <div className="text-center text-gray-400 py-12">
                        <Layout className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p>从左侧拖拽组件到此处开始设计表单</p>
                      </div>
                    )}

                    {/* 按钮区域 */}
                    <div className="border-t pt-4 mt-6">
                      <h5 className="font-medium text-gray-900 mb-3">操作按钮</h5>
                      <div className="flex items-center space-x-3">
                        {/* 主要按钮 */}
                        <button className="px-4 py-2 bg-green-600 text-white rounded-md text-sm font-medium hover:bg-green-700">
                          通过
                        </button>
                        <button className="px-4 py-2 bg-red-600 text-white rounded-md text-sm font-medium hover:bg-red-700">
                          驳回
                        </button>
                        
                        {/* 更多按钮下拉菜单 */}
                        <div className="relative">
                          <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md text-sm font-medium hover:bg-gray-50 flex items-center">
                            更多
                            <ChevronDown className="w-4 h-4 ml-1" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 属性配置面板 */}
              <div className="col-span-3">
                <h4 className="font-medium text-gray-900 mb-3">属性配置</h4>
                <div className="border border-gray-200 rounded-lg p-4">
                  {renderPropertyPanel()}
                </div>
              </div>
            </div>
          </div>

          {/* 按钮配置 */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">按钮接口配置</h3>
            
            <div className="space-y-4">
              {formButtons.map(button => (
                <div key={button.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{button.label}</span>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        button.type === 'approve' ? 'bg-green-100 text-green-800' :
                        button.type === 'reject' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {button.type}
                      </span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 items-end">
                    <div className="col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        接口地址
                      </label>
                      <input
                        type="url"
                        value={button.apiUrl}
                        onChange={(e) => setFormButtons(prev => prev.map(b => 
                          b.id === button.id ? { ...b, apiUrl: e.target.value } : b
                        ))}
                        placeholder="http://example.com/api/action?param=value"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    
                    <div>
                      <button
                        onClick={() => handleButtonTest(button.id)}
                        disabled={button.testStatus === 'testing' || !button.apiUrl.trim()}
                        className="w-full inline-flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                      >
                        <TestTube className="w-4 h-4 mr-2" />
                        {button.testStatus === 'testing' ? '测试中' : '测试'}
                      </button>
                    </div>
                  </div>
                  
                  {button.testMessage && (
                    <div className={`mt-2 flex items-center space-x-2 text-sm ${
                      button.testStatus === 'success' ? 'text-green-600' :
                      button.testStatus === 'error' ? 'text-red-600' :
                      'text-blue-600'
                    }`}>
                      {button.testStatus === 'success' && <CheckCircle className="w-4 h-4" />}
                      {button.testStatus === 'error' && <XCircle className="w-4 h-4" />}
                      <span>{button.testMessage}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* 版本历史模态框 */}
      <Modal
        open={showVersionModal}
        onClose={() => setShowVersionModal(false)}
        title="表单版本历史"
        width="max-w-2xl"
      >
        <div className="space-y-4">
          {formVersions.map(version => (
            <div key={version.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
              <div>
                <div className="font-medium">{version.name}</div>
                <div className="text-sm text-gray-500">
                  创建时间: {version.createdAt} | 表单ID: {version.formId}
                </div>
                {version.description && (
                  <div className="text-sm text-gray-600 mt-1">{version.description}</div>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 rounded-full text-xs ${
                  version.status === 'published' ? 'bg-green-100 text-green-800' :
                  version.status === 'draft' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {version.status === 'published' ? '已发布' : 
                   version.status === 'draft' ? '草稿' : '已归档'}
                </span>
                <button className="px-3 py-1 text-sm border border-gray-300 rounded hover:bg-gray-50">
                  预览
                </button>
                <button className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700">
                  恢复
                </button>
              </div>
            </div>
          ))}
        </div>
      </Modal>
    </div>
  );
};