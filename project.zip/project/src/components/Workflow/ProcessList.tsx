import React, { useState } from 'react';
import { ArrowLeft, Edit, Eye, Plus, Trash2, Shield, Users } from 'lucide-react';
import { Table } from '../Common/Table';
import { Modal } from '../Common/Modal';
import { PermissionModal } from '../Common/PermissionModal';
import { ProcessEditor } from './ProcessEditor';
import { Process, PermissionModalData } from '../../types';
import { useAuth } from '../../hooks/useAuth';

interface ProcessListProps {
  systemId: string;
  systemName: string;
  onBack: () => void;
  onViewNodes: (processId: string, processName: string) => void;
}

export const ProcessList: React.FC<ProcessListProps> = ({
  systemId,
  systemName,
  onBack,
  onViewNodes
}) => {
  const { user, hasPermission, isSuperAdmin, canGrantPermissions } = useAuth();
  const [processes, setProcesses] = useState<Process[]>([
    {
      id: '1',
      systemId,
      name: '合同审批流程',
      description: '客户合同审批流程',
      createdAt: '2024-01-15',
      status: 'active',
      nodeCount: 4,
      createdBy: '1',
      permissions: [
        {
          userId: '2',
          username: 'manager',
          actions: ['view', 'edit'],
          grantedBy: '1',
          grantedAt: '2024-01-15T00:00:00Z'
        }
      ]
    },
    {
      id: '2',
      systemId,
      name: '费用报销流程',
      description: '员工费用报销审批流程',
      createdAt: '2024-01-12',
      status: 'active',
      nodeCount: 3,
      createdBy: '2',
      permissions: [
        {
          userId: '3',
          username: 'operator',
          actions: ['view'],
          grantedBy: '2',
          grantedAt: '2024-01-20T00:00:00Z'
        }
      ]
    },
    {
      id: '3',
      systemId,
      name: '请假申请流程',
      description: '员工请假申请流程',
      createdAt: '2024-01-10',
      status: 'inactive',
      nodeCount: 2,
      createdBy: '1',
      permissions: []
    }
  ]);

  const [modalOpen, setModalOpen] = useState(false);
  const [permissionModalOpen, setPermissionModalOpen] = useState(false);
  const [editingProcess, setEditingProcess] = useState<Process | null>(null);
  const [permissionModalData, setPermissionModalData] = useState<PermissionModalData | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [editingProcessId, setEditingProcessId] = useState<string | null>(null);
  const [editingProcessName, setEditingProcessName] = useState<string>('');

  // Filter processes based on user permissions
  const getVisibleProcesses = () => {
    if (isSuperAdmin()) return processes;
    
    return processes.filter(process => 
      hasPermission('process', process.id, 'view') || 
      process.createdBy === user?.id ||
      hasPermission('system', systemId, 'view')
    );
  };

  const columns = [
    {
      key: 'name',
      title: '流程名称',
      width: '25%',
      render: (name: string, record: Process) => (
        <div className="flex items-center space-x-2">
          {(hasPermission('process', record.id, 'view') || isSuperAdmin()) ? (
            <button
              onClick={() => onViewNodes(record.id, record.name)}
              className="text-blue-600 hover:text-blue-800 hover:underline font-medium"
              title="进入节点管理"
            >
              {name}
            </button>
          ) : (
            <span>{name}</span>
          )}
        </div>
      )
    },
    {
      key: 'description',
      title: '描述',
      width: '30%'
    },
    {
      key: 'nodeCount',
      title: '节点数量',
      width: '10%'
    },
    {
      key: 'permissions',
      title: '授权用户',
      width: '10%',
      render: (permissions: any[]) => (
        <div className="flex items-center space-x-1">
          <Users className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-600">
            {permissions.length} 人
          </span>
        </div>
      )
    },
    {
      key: 'status',
      title: '状态',
      width: '10%',
      render: (status: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          status === 'active' 
            ? 'bg-green-100 text-green-800' 
            : 'bg-gray-100 text-gray-800'
        }`}>
          {status === 'active' ? '启用' : '禁用'}
        </span>
      )
    },
    {
      key: 'createdAt',
      title: '创建时间',
      width: '10%'
    },
    {
      key: 'actions',
      title: '操作',
      width: '15%',
      render: (_: any, record: Process) => (
        <div className="flex space-x-2">
          {(hasPermission('process', record.id, 'edit') || isSuperAdmin()) && (
            <button
              onClick={() => handleEdit(record)}
              className="p-1 text-blue-600 hover:bg-blue-50 rounded"
              title="编辑"
            >
              <Edit className="w-4 h-4" />
            </button>
          )}
          {(canGrantPermissions('process', record.id) || isSuperAdmin()) && (
            <button
              onClick={() => handlePermissionConfig(record)}
              className="p-1 text-purple-600 hover:bg-purple-50 rounded"
              title="权限配置"
            >
              <Shield className="w-4 h-4" />
            </button>
          )}
          {(hasPermission('process', record.id, 'delete') || isSuperAdmin()) && (
            <button
              onClick={() => handleDelete(record.id)}
              className="p-1 text-red-600 hover:bg-red-50 rounded"
              title="删除"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      )
    }
  ];

  const handleEdit = (process: Process) => {
    setEditingProcessId(process.id);
    setEditingProcessName(process.name);
  };

  const handlePermissionConfig = (process: Process) => {
    setPermissionModalData({
      resourceType: 'process',
      resourceId: process.id,
      resourceName: process.name,
      currentPermissions: process.permissions
    });
    setPermissionModalOpen(true);
  };

  const handleDelete = (processId: string) => {
    if (confirm('确定要删除这个流程吗？')) {
      setProcesses(processes.filter(p => p.id !== processId));
    }
  };

  const handleAdd = () => {
    setEditingProcess(null);
    setModalOpen(true);
  };

  const handlePermissionSave = (permissions: any[]) => {
    if (!permissionModalData) return;
    
    setProcesses(processes.map(process => 
      process.id === permissionModalData.resourceId
        ? { ...process, permissions }
        : process
    ));
  };

  const visibleProcesses = getVisibleProcesses();
  const filteredProcesses = visibleProcesses.filter(process =>
    process.name.toLowerCase().includes(searchValue.toLowerCase()) ||
    process.description.toLowerCase().includes(searchValue.toLowerCase())
  );

  const canCreateProcess = hasPermission('system', systemId, 'edit') || isSuperAdmin();

  // 如果正在编辑流程，显示流程编辑器
  if (editingProcessId) {
    return (
      <ProcessEditor
        processId={editingProcessId}
        processName={editingProcessName}
        onBack={() => {
          setEditingProcessId(null);
          setEditingProcessName('');
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={onBack}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">流程管理</h2>
            <p className="text-gray-600">系统：{systemName}</p>
          </div>
        </div>
        {canCreateProcess && (
          <button
            onClick={handleAdd}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            新增流程
          </button>
        )}
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Shield className="w-5 h-5 text-amber-600 mt-0.5" />
          <div>
            <h4 className="font-medium text-amber-900">流程权限说明</h4>
            <p className="text-sm text-amber-700 mt-1">
              • 拥有系统权限的用户可以查看该系统下的所有流程
              • 流程创建者可以配置该流程的访问权限
              • 被授权用户可以根据权限级别进行相应操作
            </p>
          </div>
        </div>
      </div>

      <Table
        columns={columns}
        data={filteredProcesses}
        searchable
        searchValue={searchValue}
        onSearch={setSearchValue}
        pagination={{
          current: currentPage,
          total: filteredProcesses.length,
          pageSize: 10,
          onChange: setCurrentPage
        }}
      />

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingProcess ? '编辑流程' : '新增流程'}
        footer={
          <>
            <button
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              取消
            </button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
              保存
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              流程名称
            </label>
            <input
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              defaultValue={editingProcess?.name}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              描述
            </label>
            <textarea
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              defaultValue={editingProcess?.description}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              状态
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              defaultValue={editingProcess?.status}
            >
              <option value="active">启用</option>
              <option value="inactive">禁用</option>
            </select>
          </div>
        </div>
      </Modal>

      <PermissionModal
        open={permissionModalOpen}
        onClose={() => setPermissionModalOpen(false)}
        data={permissionModalData}
        onSave={handlePermissionSave}
      />
    </div>
  );
};