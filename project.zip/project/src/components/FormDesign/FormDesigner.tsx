import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Settings, 
  Eye, 
  Code, 
  FileText, 
  Type, 
  Hash, 
  Calendar, 
  ToggleLeft, 
  List, 
  Mail, 
  Phone, 
  Link, 
  Upload, 
  CheckSquare,
  Edit,
  Check,
  X,
  RotateCcw,
  UserPlus,
  Copy,
  Download,
  Smartphone,
  Monitor,
  ChevronDown,
  ChevronRight,
  AlertCircle,
  Info,
  BookOpen
} from 'lucide-react';

interface FormField {
  id: string;
  type: 'text' | 'number' | 'email' | 'phone' | 'date' | 'select' | 'checkbox' | 'textarea' | 'file' | 'url';
  label: string;
  placeholder?: string;
  required: boolean;
  options?: string[];
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
  };
}

interface FormButton {
  id: string;
  type: 'approve' | 'reject' | 'return' | 'transfer' | 'countersign';
  label: string;
  color: 'green' | 'red' | 'yellow' | 'blue' | 'purple' | 'gray';
  confirmText?: string;
  icon: string;
}

export const FormDesigner: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'design' | 'preview' | 'test'>('design');
  const [previewDevice, setPreviewDevice] = useState<'mobile' | 'desktop'>('mobile');
  const [formFields, setFormFields] = useState<FormField[]>([]);
  const [formButtons, setFormButtons] = useState<FormButton[]>([]);
  const [selectedField, setSelectedField] = useState<FormField | null>(null);
  const [selectedButton, setSelectedButton] = useState<FormButton | null>(null);
  const [formTitle, setFormTitle] = useState('合同审批表单');
  const [formDescription, setFormDescription] = useState('请填写合同相关信息');

  // 测试页面状态
  const [requestBody, setRequestBody] = useState('');
  const [debugResult, setDebugResult] = useState<any>(null);
  const [isDebugging, setIsDebugging] = useState(false);

  const fieldTypes = [
    { type: 'text', label: '单行文本', icon: <Type className="w-4 h-4" /> },
    { type: 'textarea', label: '多行文本', icon: <FileText className="w-4 h-4" /> },
    { type: 'number', label: '数字', icon: <Hash className="w-4 h-4" /> },
    { type: 'email', label: '邮箱', icon: <Mail className="w-4 h-4" /> },
    { type: 'phone', label: '手机号', icon: <Phone className="w-4 h-4" /> },
    { type: 'date', label: '日期', icon: <Calendar className="w-4 h-4" /> },
    { type: 'select', label: '下拉选择', icon: <List className="w-4 h-4" /> },
    { type: 'checkbox', label: '复选框', icon: <CheckSquare className="w-4 h-4" /> },
    { type: 'file', label: '文件上传', icon: <Upload className="w-4 h-4" /> },
    { type: 'url', label: '链接', icon: <Link className="w-4 h-4" /> }
  ];

  const buttonTypes = [
    { type: 'approve', label: '通过按钮', icon: '✓', color: 'green' as const },
    { type: 'reject', label: '驳回按钮', icon: '✗', color: 'red' as const },
    { type: 'return', label: '回退按钮', icon: '↩', color: 'yellow' as const },
    { type: 'transfer', label: '转交按钮', icon: '→', color: 'blue' as const },
    { type: 'countersign', label: '加签按钮', icon: '+', color: 'purple' as const }
  ];

  const addField = (type: FormField['type']) => {
    const newField: FormField = {
      id: Date.now().toString(),
      type,
      label: `${fieldTypes.find(f => f.type === type)?.label}`,
      placeholder: `请输入${fieldTypes.find(f => f.type === type)?.label}`,
      required: false,
      options: type === 'select' ? ['选项1', '选项2', '选项3'] : undefined
    };
    setFormFields([...formFields, newField]);
    setSelectedField(newField);
    setSelectedButton(null);
  };

  const addButton = (type: FormButton['type']) => {
    const buttonType = buttonTypes.find(b => b.type === type);
    if (!buttonType) return;

    const newButton: FormButton = {
      id: Date.now().toString(),
      type,
      label: buttonType.label.replace('按钮', ''),
      color: buttonType.color,
      confirmText: `确定要${buttonType.label.replace('按钮', '')}吗？`,
      icon: buttonType.icon
    };
    setFormButtons([...formButtons, newButton]);
    setSelectedButton(newButton);
    setSelectedField(null);
  };

  const updateField = (id: string, updates: Partial<FormField>) => {
    setFormFields(formFields.map(field => 
      field.id === id ? { ...field, ...updates } : field
    ));
    if (selectedField?.id === id) {
      setSelectedField({ ...selectedField, ...updates });
    }
  };

  const updateButton = (id: string, updates: Partial<FormButton>) => {
    setFormButtons(formButtons.map(button => 
      button.id === id ? { ...button, ...updates } : button
    ));
    if (selectedButton?.id === id) {
      setSelectedButton({ ...selectedButton, ...updates });
    }
  };

  const deleteField = (id: string) => {
    setFormFields(formFields.filter(field => field.id !== id));
    if (selectedField?.id === id) {
      setSelectedField(null);
    }
  };

  const deleteButton = (id: string) => {
    setFormButtons(formButtons.filter(button => button.id !== id));
    if (selectedButton?.id === id) {
      setSelectedButton(null);
    }
  };

  const generateRequestBody = () => {
    const sampleData: any = {};
    formFields.forEach(field => {
      switch (field.type) {
        case 'text':
        case 'textarea':
          sampleData[field.id] = field.label.includes('合同') ? 'CONTRACT-2024-001' : 
                                 field.label.includes('名称') ? '张三' : '示例文本';
          break;
        case 'number':
          sampleData[field.id] = field.label.includes('金额') ? 100000 : 
                                field.label.includes('数量') ? 10 : 123;
          break;
        case 'email':
          sampleData[field.id] = 'user@example.com';
          break;
        case 'phone':
          sampleData[field.id] = '13800138000';
          break;
        case 'date':
          sampleData[field.id] = '2024-01-15';
          break;
        case 'select':
          sampleData[field.id] = field.options?.[0] || '选项1';
          break;
        case 'checkbox':
          sampleData[field.id] = true;
          break;
        case 'url':
          sampleData[field.id] = 'https://example.com';
          break;
        case 'file':
          sampleData[field.id] = 'file_id_12345';
          break;
      }
    });
    return JSON.stringify(sampleData, null, 2);
  };

  const handleDebug = async () => {
    setIsDebugging(true);
    
    // 模拟API调用
    setTimeout(() => {
      try {
        const data = JSON.parse(requestBody);
        const errors: string[] = [];
        
        // 验证必填字段
        formFields.forEach(field => {
          if (field.required && !data[field.id]) {
            errors.push(`${field.label}为必填字段`);
          }
        });
        
        // 验证数据格式
        formFields.forEach(field => {
          if (data[field.id]) {
            switch (field.type) {
              case 'email':
                if (!/\S+@\S+\.\S+/.test(data[field.id])) {
                  errors.push(`${field.label}格式不正确`);
                }
                break;
              case 'phone':
                if (!/^1[3-9]\d{9}$/.test(data[field.id])) {
                  errors.push(`${field.label}格式不正确`);
                }
                break;
              case 'number':
                if (isNaN(data[field.id])) {
                  errors.push(`${field.label}必须为数字`);
                }
                break;
            }
          }
        });
        
        if (errors.length > 0) {
          setDebugResult({
            success: false,
            statusCode: 400,
            message: '请求参数验证失败',
            errors,
            timestamp: new Date().toISOString(),
            requestData: data
          });
        } else {
          setDebugResult({
            success: true,
            statusCode: 200,
            message: '表单提交成功',
            data: {
              formId: 'form_' + Date.now(),
              processId: 'process_' + Date.now(),
              status: 'pending'
            },
            timestamp: new Date().toISOString(),
            requestData: data
          });
        }
      } catch (error) {
        setDebugResult({
          success: false,
          statusCode: 400,
          message: 'JSON格式错误',
          errors: ['请求体必须是有效的JSON格式'],
          timestamp: new Date().toISOString()
        });
      }
      setIsDebugging(false);
    }, 1500);
  };

  const resetRequestBody = () => {
    setRequestBody(generateRequestBody());
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  React.useEffect(() => {
    if (activeTab === 'test' && !requestBody) {
      setRequestBody(generateRequestBody());
    }
  }, [activeTab, formFields]);

  const renderFieldConfig = () => {
    if (!selectedField) return null;

    return (
      <div className="space-y-4">
        <h3 className="font-medium text-gray-900">字段配置</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            字段标签
          </label>
          <input
            type="text"
            value={selectedField.label}
            onChange={(e) => updateField(selectedField.id, { label: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            占位符
          </label>
          <input
            type="text"
            value={selectedField.placeholder || ''}
            onChange={(e) => updateField(selectedField.id, { placeholder: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            id="required"
            checked={selectedField.required}
            onChange={(e) => updateField(selectedField.id, { required: e.target.checked })}
            className="mr-2 rounded border-gray-300"
          />
          <label htmlFor="required" className="text-sm text-gray-700">
            必填字段
          </label>
        </div>

        {selectedField.type === 'select' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              选项配置
            </label>
            <div className="space-y-2">
              {selectedField.options?.map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={option}
                    onChange={(e) => {
                      const newOptions = [...(selectedField.options || [])];
                      newOptions[index] = e.target.value;
                      updateField(selectedField.id, { options: newOptions });
                    }}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <button
                    onClick={() => {
                      const newOptions = selectedField.options?.filter((_, i) => i !== index);
                      updateField(selectedField.id, { options: newOptions });
                    }}
                    className="p-2 text-red-600 hover:bg-red-50 rounded"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
              <button
                onClick={() => {
                  const newOptions = [...(selectedField.options || []), `选项${(selectedField.options?.length || 0) + 1}`];
                  updateField(selectedField.id, { options: newOptions });
                }}
                className="w-full px-3 py-2 border border-dashed border-gray-300 rounded-md text-gray-500 hover:border-gray-400"
              >
                + 添加选项
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderButtonConfig = () => {
    if (!selectedButton) return null;

    const colorOptions = [
      { value: 'green', label: '绿色', class: 'bg-green-500' },
      { value: 'red', label: '红色', class: 'bg-red-500' },
      { value: 'yellow', label: '黄色', class: 'bg-yellow-500' },
      { value: 'blue', label: '蓝色', class: 'bg-blue-500' },
      { value: 'purple', label: '紫色', class: 'bg-purple-500' },
      { value: 'gray', label: '灰色', class: 'bg-gray-500' }
    ];

    return (
      <div className="space-y-4">
        <h3 className="font-medium text-gray-900">按钮配置</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            按钮文本
          </label>
          <input
            type="text"
            value={selectedButton.label}
            onChange={(e) => updateButton(selectedButton.id, { label: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            确认提示
          </label>
          <input
            type="text"
            value={selectedButton.confirmText || ''}
            onChange={(e) => updateButton(selectedButton.id, { confirmText: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="点击按钮时的确认提示语"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            按钮颜色
          </label>
          <div className="grid grid-cols-3 gap-2">
            {colorOptions.map((color) => (
              <button
                key={color.value}
                onClick={() => updateButton(selectedButton.id, { color: color.value as any })}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md border ${
                  selectedButton.color === color.value 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-300 hover:bg-gray-50'
                }`}
              >
                <div className={`w-4 h-4 rounded ${color.class}`}></div>
                <span className="text-sm">{color.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const renderFormPreview = () => {
    const getButtonColorClass = (color: string) => {
      switch (color) {
        case 'green': return 'bg-green-600 hover:bg-green-700';
        case 'red': return 'bg-red-600 hover:bg-red-700';
        case 'yellow': return 'bg-yellow-600 hover:bg-yellow-700';
        case 'blue': return 'bg-blue-600 hover:bg-blue-700';
        case 'purple': return 'bg-purple-600 hover:bg-purple-700';
        case 'gray': return 'bg-gray-600 hover:bg-gray-700';
        default: return 'bg-blue-600 hover:bg-blue-700';
      }
    };

    return (
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-2">{formTitle}</h3>
          <p className="text-sm text-gray-600">{formDescription}</p>
        </div>

        <div className="space-y-4">
          {formFields.map((field) => (
            <div key={field.id}>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {field.label}
                {field.required && <span className="text-red-500 ml-1">*</span>}
              </label>
              
              {field.type === 'textarea' ? (
                <textarea
                  placeholder={field.placeholder}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              ) : field.type === 'select' ? (
                <select className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                  <option value="">请选择</option>
                  {field.options?.map((option, index) => (
                    <option key={index} value={option}>{option}</option>
                  ))}
                </select>
              ) : field.type === 'checkbox' ? (
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    className="mr-2 rounded border-gray-300"
                  />
                  <span className="text-sm text-gray-700">{field.placeholder}</span>
                </div>
              ) : field.type === 'file' ? (
                <div className="border-2 border-dashed border-gray-300 rounded-md p-4 text-center">
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">点击上传文件</p>
                </div>
              ) : (
                <input
                  type={field.type}
                  placeholder={field.placeholder}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              )}
            </div>
          ))}
        </div>

        {formButtons.length > 0 && (
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className={`flex ${previewDevice === 'mobile' ? 'flex-col space-y-3' : 'flex-row space-x-3 justify-end'}`}>
              {formButtons.map((button) => (
                <button
                  key={button.id}
                  className={`${getButtonColorClass(button.color)} text-white px-6 py-2 rounded-md transition-colors ${
                    previewDevice === 'mobile' ? 'w-full' : ''
                  }`}
                >
                  <span className="mr-2">{button.icon}</span>
                  {button.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderTestTab = () => (
    <div className="grid grid-cols-3 gap-6 h-full">
      {/* 左栏：请求体编辑 */}
      <div className="space-y-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-gray-900">API 调试</h3>
            <div className="flex space-x-2">
              <button
                onClick={resetRequestBody}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded"
                title="重置为示例数据"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={() => copyToClipboard(requestBody)}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded"
                title="复制请求体"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="space-y-3">
            <div className="text-sm">
              <div className="grid grid-cols-2 gap-2 mb-2">
                <div><strong>URL:</strong></div>
                <div className="font-mono text-xs">/api/form/submit</div>
                <div><strong>Method:</strong></div>
                <div><span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">POST</span></div>
                <div><strong>Content-Type:</strong></div>
                <div className="font-mono text-xs">application/json</div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                请求体 (JSON)
              </label>
              <textarea
                value={requestBody}
                onChange={(e) => setRequestBody(e.target.value)}
                rows={12}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono text-sm"
                placeholder="请输入JSON格式的请求体"
              />
            </div>

            <button
              onClick={handleDebug}
              disabled={isDebugging || !requestBody.trim()}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {isDebugging ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  调试中...
                </>
              ) : (
                <>
                  <Code className="w-4 h-4 mr-2" />
                  发送调试请求
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 中栏：调试结果 */}
      <div className="space-y-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-gray-900">调试结果</h3>
            {debugResult && (
              <button
                onClick={() => copyToClipboard(JSON.stringify(debugResult, null, 2))}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded"
                title="复制结果"
              >
                <Copy className="w-4 h-4" />
              </button>
            )}
          </div>

          {!debugResult ? (
            <div className="text-center py-8 text-gray-500">
              <Code className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>点击"发送调试请求"查看结果</p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* 状态概览 */}
              <div className={`p-3 rounded-lg ${
                debugResult.success 
                  ? 'bg-green-50 border border-green-200' 
                  : 'bg-red-50 border border-red-200'
              }`}>
                <div className="flex items-center space-x-2 mb-2">
                  {debugResult.success ? (
                    <Check className="w-5 h-5 text-green-600" />
                  ) : (
                    <X className="w-5 h-5 text-red-600" />
                  )}
                  <span className={`font-medium ${
                    debugResult.success ? 'text-green-800' : 'text-red-800'
                  }`}>
                    {debugResult.success ? '调试成功' : '调试失败'}
                  </span>
                  <span className={`px-2 py-1 rounded text-xs ${
                    debugResult.statusCode === 200 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {debugResult.statusCode}
                  </span>
                </div>
                <p className={`text-sm ${
                  debugResult.success ? 'text-green-700' : 'text-red-700'
                }`}>
                  {debugResult.message}
                </p>
              </div>

              {/* 错误详情 */}
              {debugResult.errors && debugResult.errors.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <h4 className="font-medium text-red-800 mb-2">验证错误</h4>
                  <ul className="space-y-1">
                    {debugResult.errors.map((error: string, index: number) => (
                      <li key={index} className="text-sm text-red-700 flex items-start">
                        <span className="text-red-500 mr-2">•</span>
                        {error}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* 响应数据 */}
              {debugResult.data && (
                <div className="bg-gray-50 rounded-lg p-3">
                  <h4 className="font-medium text-gray-800 mb-2">响应数据</h4>
                  <pre className="text-sm text-gray-700 overflow-x-auto">
                    {JSON.stringify(debugResult.data, null, 2)}
                  </pre>
                </div>
              )}

              {/* 请求详情 */}
              <div className="bg-gray-50 rounded-lg p-3">
                <h4 className="font-medium text-gray-800 mb-2">请求详情</h4>
                <div className="text-sm text-gray-600 space-y-1">
                  <div><strong>时间:</strong> {new Date(debugResult.timestamp).toLocaleString()}</div>
                  <div><strong>请求数据:</strong></div>
                  <pre className="text-xs bg-white p-2 rounded border overflow-x-auto">
                    {JSON.stringify(debugResult.requestData, null, 2)}
                  </pre>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 右栏：开发文档 */}
      <div className="space-y-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4 max-h-full overflow-y-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-gray-900">开发文档</h3>
            <button
              onClick={() => {
                const docContent = document.querySelector('.api-documentation')?.textContent || '';
                copyToClipboard(docContent);
              }}
              className="p-2 text-gray-600 hover:bg-gray-100 rounded"
              title="复制文档"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>

          <div className="api-documentation space-y-6 text-sm">
            {/* 概述 */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-2 pb-1 border-b border-gray-200">概述</h4>
              <div className="bg-gray-50 rounded p-3 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div className="text-gray-600">表单名称:</div>
                  <div className="font-medium">{formTitle}</div>
                  <div className="text-gray-600">字段数量:</div>
                  <div className="font-medium">{formFields.length} 个</div>
                  <div className="text-gray-600">按钮数量:</div>
                  <div className="font-medium">{formButtons.length} 个</div>
                  <div className="text-gray-600">API版本:</div>
                  <div className="font-medium">v1.0</div>
                </div>
              </div>
            </div>

            {/* HTTP接口 */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-2 pb-1 border-b border-gray-200">HTTP接口</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border border-gray-200">
                  <tbody>
                    <tr className="border-b border-gray-200">
                      <td className="px-2 py-1 bg-gray-50 font-medium">HTTP URL</td>
                      <td className="px-2 py-1">https://api.example.com/api/form/submit</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="px-2 py-1 bg-gray-50 font-medium">HTTP Method</td>
                      <td className="px-2 py-1"><span className="bg-green-100 text-green-800 px-1 rounded">POST</span></td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="px-2 py-1 bg-gray-50 font-medium">编码类型</td>
                      <td className="px-2 py-1">application/json</td>
                    </tr>
                    <tr>
                      <td className="px-2 py-1 bg-gray-50 font-medium">是否需要登录</td>
                      <td className="px-2 py-1">是</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* 请求头 */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-2 pb-1 border-b border-gray-200">请求头</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border border-gray-200">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-2 py-1 text-left border-r border-gray-200">名称</th>
                      <th className="px-2 py-1 text-left border-r border-gray-200">类型</th>
                      <th className="px-2 py-1 text-left border-r border-gray-200">必填</th>
                      <th className="px-2 py-1 text-left">说明</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-gray-200">
                      <td className="px-2 py-1 border-r border-gray-200 font-mono">Content-Type</td>
                      <td className="px-2 py-1 border-r border-gray-200">string</td>
                      <td className="px-2 py-1 border-r border-gray-200 text-red-600">是</td>
                      <td className="px-2 py-1">application/json</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="px-2 py-1 border-r border-gray-200 font-mono">Authorization</td>
                      <td className="px-2 py-1 border-r border-gray-200">string</td>
                      <td className="px-2 py-1 border-r border-gray-200 text-red-600">是</td>
                      <td className="px-2 py-1">Bearer token</td>
                    </tr>
                    <tr>
                      <td className="px-2 py-1 border-r border-gray-200 font-mono">X-Request-ID</td>
                      <td className="px-2 py-1 border-r border-gray-200">string</td>
                      <td className="px-2 py-1 border-r border-gray-200 text-gray-600">否</td>
                      <td className="px-2 py-1">请求唯一标识</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* 请求参数 */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-2 pb-1 border-b border-gray-200">请求参数</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border border-gray-200">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-2 py-1 text-left border-r border-gray-200">名称</th>
                      <th className="px-2 py-1 text-left border-r border-gray-200">类型</th>
                      <th className="px-2 py-1 text-left border-r border-gray-200">必填</th>
                      <th className="px-2 py-1 text-left border-r border-gray-200">说明</th>
                      <th className="px-2 py-1 text-left">示例值</th>
                    </tr>
                  </thead>
                  <tbody>
                    {formFields.map((field, index) => (
                      <tr key={field.id} className={index < formFields.length - 1 ? "border-b border-gray-200" : ""}>
                        <td className="px-2 py-1 border-r border-gray-200 font-mono">{field.id}</td>
                        <td className="px-2 py-1 border-r border-gray-200">
                          {field.type === 'number' ? 'number' : 
                           field.type === 'checkbox' ? 'boolean' :
                           field.type === 'file' ? 'string' : 'string'}
                        </td>
                        <td className="px-2 py-1 border-r border-gray-200">
                          <span className={field.required ? 'text-red-600' : 'text-gray-600'}>
                            {field.required ? '是' : '否'}
                          </span>
                        </td>
                        <td className="px-2 py-1 border-r border-gray-200">{field.label}</td>
                        <td className="px-2 py-1 font-mono text-blue-600">
                          {field.type === 'email' ? '"user@example.com"' :
                           field.type === 'phone' ? '"13800138000"' :
                           field.type === 'number' ? '100000' :
                           field.type === 'date' ? '"2024-01-15"' :
                           field.type === 'checkbox' ? 'true' :
                           field.type === 'select' ? `"${field.options?.[0] || '选项1'}"` :
                           '"示例文本"'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 请求示例 */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-2 pb-1 border-b border-gray-200">请求示例</h4>
              
              <div className="space-y-3">
                <div>
                  <h5 className="font-medium text-gray-800 mb-1">cURL</h5>
                  <div className="bg-gray-900 text-green-400 p-3 rounded text-xs font-mono overflow-x-auto">
{`curl -X POST https://api.example.com/api/form/submit \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer YOUR_TOKEN" \\
  -d '${generateRequestBody()}'`}
                  </div>
                </div>

                <div>
                  <h5 className="font-medium text-gray-800 mb-1">JavaScript</h5>
                  <div className="bg-gray-900 text-green-400 p-3 rounded text-xs font-mono overflow-x-auto">
{`const response = await fetch('https://api.example.com/api/form/submit', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_TOKEN'
  },
  body: JSON.stringify(${generateRequestBody()})
});

const result = await response.json();
console.log(result);`}
                  </div>
                </div>
              </div>
            </div>

            {/* 响应参数 */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-2 pb-1 border-b border-gray-200">响应参数</h4>
              
              <div className="space-y-3">
                <div>
                  <h5 className="font-medium text-gray-800 mb-1">成功响应 (200)</h5>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs border border-gray-200">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="px-2 py-1 text-left border-r border-gray-200">名称</th>
                          <th className="px-2 py-1 text-left border-r border-gray-200">类型</th>
                          <th className="px-2 py-1 text-left">说明</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b border-gray-200">
                          <td className="px-2 py-1 border-r border-gray-200 font-mono">code</td>
                          <td className="px-2 py-1 border-r border-gray-200">number</td>
                          <td className="px-2 py-1">状态码，200表示成功</td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td className="px-2 py-1 border-r border-gray-200 font-mono">message</td>
                          <td className="px-2 py-1 border-r border-gray-200">string</td>
                          <td className="px-2 py-1">响应消息</td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td className="px-2 py-1 border-r border-gray-200 font-mono">data.formId</td>
                          <td className="px-2 py-1 border-r border-gray-200">string</td>
                          <td className="px-2 py-1">表单ID</td>
                        </tr>
                        <tr>
                          <td className="px-2 py-1 border-r border-gray-200 font-mono">data.processId</td>
                          <td className="px-2 py-1 border-r border-gray-200">string</td>
                          <td className="px-2 py-1">流程ID</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                <div>
                  <h5 className="font-medium text-gray-800 mb-1">错误响应 (400/500)</h5>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs border border-gray-200">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="px-2 py-1 text-left border-r border-gray-200">名称</th>
                          <th className="px-2 py-1 text-left border-r border-gray-200">类型</th>
                          <th className="px-2 py-1 text-left">说明</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b border-gray-200">
                          <td className="px-2 py-1 border-r border-gray-200 font-mono">code</td>
                          <td className="px-2 py-1 border-r border-gray-200">number</td>
                          <td className="px-2 py-1">错误状态码</td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td className="px-2 py-1 border-r border-gray-200 font-mono">message</td>
                          <td className="px-2 py-1 border-r border-gray-200">string</td>
                          <td className="px-2 py-1">错误消息</td>
                        </tr>
                        <tr>
                          <td className="px-2 py-1 border-r border-gray-200 font-mono">errors</td>
                          <td className="px-2 py-1 border-r border-gray-200">array</td>
                          <td className="px-2 py-1">详细错误信息列表</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            {/* 错误码说明 */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-2 pb-1 border-b border-gray-200">错误码说明</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border border-gray-200">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-2 py-1 text-left border-r border-gray-200">错误码</th>
                      <th className="px-2 py-1 text-left border-r border-gray-200">HTTP状态码</th>
                      <th className="px-2 py-1 text-left">说明</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-gray-200">
                      <td className="px-2 py-1 border-r border-gray-200 font-mono">200</td>
                      <td className="px-2 py-1 border-r border-gray-200"><span className="bg-green-100 text-green-800 px-1 rounded">200</span></td>
                      <td className="px-2 py-1">请求成功</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="px-2 py-1 border-r border-gray-200 font-mono">400</td>
                      <td className="px-2 py-1 border-r border-gray-200"><span className="bg-red-100 text-red-800 px-1 rounded">400</span></td>
                      <td className="px-2 py-1">请求参数错误</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="px-2 py-1 border-r border-gray-200 font-mono">401</td>
                      <td className="px-2 py-1 border-r border-gray-200"><span className="bg-red-100 text-red-800 px-1 rounded">401</span></td>
                      <td className="px-2 py-1">未授权访问</td>
                    </tr>
                    <tr className="border-b border-gray-200">
                      <td className="px-2 py-1 border-r border-gray-200 font-mono">403</td>
                      <td className="px-2 py-1 border-r border-gray-200"><span className="bg-red-100 text-red-800 px-1 rounded">403</span></td>
                      <td className="px-2 py-1">权限不足</td>
                    </tr>
                    <tr>
                      <td className="px-2 py-1 border-r border-gray-200 font-mono">500</td>
                      <td className="px-2 py-1 border-r border-gray-200"><span className="bg-red-100 text-red-800 px-1 rounded">500</span></td>
                      <td className="px-2 py-1">服务器内部错误</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* 注意事项 */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-2 pb-1 border-b border-gray-200">注意事项</h4>
              <div className="bg-blue-50 border border-blue-200 rounded p-3">
                <div className="flex items-start space-x-2">
                  <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div className="space-y-1 text-blue-800">
                    <p>• 所有请求必须包含有效的Authorization头</p>
                    <p>• 请求体必须是有效的JSON格式</p>
                    <p>• 必填字段不能为空或null</p>
                    <p>• 文件上传字段需要先通过文件上传接口获取文件ID</p>
                    <p>• API调用频率限制：每分钟最多100次请求</p>
                  </div>
                </div>
              </div>
            </div>

            {/* 更新日志 */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-2 pb-1 border-b border-gray-200">更新日志</h4>
              <div className="space-y-2">
                <div className="flex items-start space-x-3">
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium">v1.0</span>
                  <div>
                    <div className="font-medium">2024-01-15</div>
                    <div className="text-gray-600">初始版本发布，支持基础表单提交功能</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col">
      {/* 标签页导航 */}
      <div className="border-b border-gray-200 bg-white">
        <nav className="flex space-x-8 px-6">
          <button
            onClick={() => setActiveTab('design')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'design'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            🎨 表单设计
          </button>
          <button
            onClick={() => setActiveTab('preview')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'preview'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            👁️ 表单预览
          </button>
          <button
            onClick={() => setActiveTab('test')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'test'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            🧪 接口测试
          </button>
        </nav>
      </div>

      {/* 标签页内容 */}
      <div className="flex-1 overflow-hidden">
        {activeTab === 'design' && (
          <div className="h-full flex">
            {/* 左侧工具栏 */}
            <div className="w-64 bg-white border-r border-gray-200 p-4 overflow-y-auto">
              <div className="space-y-6">
                {/* 表单信息 */}
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">表单信息</h3>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        表单标题
                      </label>
                      <input
                        type="text"
                        value={formTitle}
                        onChange={(e) => setFormTitle(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        表单描述
                      </label>
                      <textarea
                        value={formDescription}
                        onChange={(e) => setFormDescription(e.target.value)}
                        rows={2}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                  </div>
                </div>

                {/* 表单字段 */}
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">表单字段</h3>
                  <div className="space-y-2">
                    {fieldTypes.map((fieldType) => (
                      <button
                        key={fieldType.type}
                        onClick={() => addField(fieldType.type)}
                        className="w-full flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        {fieldType.icon}
                        <span className="text-sm">{fieldType.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 按钮组 */}
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">按钮组</h3>
                  <div className="space-y-2">
                    {buttonTypes.map((buttonType) => (
                      <button
                        key={buttonType.type}
                        onClick={() => addButton(buttonType.type)}
                        className="w-full flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <span className="text-lg">{buttonType.icon}</span>
                        <span className="text-sm">{buttonType.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* 中间设计区域 */}
            <div className="flex-1 p-6 bg-gray-50 overflow-y-auto">
              <div className="max-w-2xl mx-auto">
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <div className="mb-6">
                    <h2 className="text-xl font-semibold text-gray-900 mb-2">{formTitle}</h2>
                    <p className="text-gray-600">{formDescription}</p>
                  </div>

                  <div className="space-y-4">
                    {formFields.map((field, index) => (
                      <div
                        key={field.id}
                        className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                          selectedField?.id === field.id
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => {
                          setSelectedField(field);
                          setSelectedButton(null);
                        }}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <label className="text-sm font-medium text-gray-700">
                            {field.label}
                            {field.required && <span className="text-red-500 ml-1">*</span>}
                          </label>
                          <div className="flex space-x-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedField(field);
                                setSelectedButton(null);
                              }}
                              className="p-1 text-gray-400 hover:text-gray-600"
                            >
                              <Settings className="w-4 h-4" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteField(field.id);
                              }}
                              className="p-1 text-red-400 hover:text-red-600"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {field.type === 'textarea' ? (
                          <textarea
                            placeholder={field.placeholder}
                            rows={3}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md"
                            readOnly
                          />
                        ) : field.type === 'select' ? (
                          <select className="w-full px-3 py-2 border border-gray-300 rounded-md" disabled>
                            <option>请选择</option>
                            {field.options?.map((option, optionIndex) => (
                              <option key={optionIndex}>{option}</option>
                            ))}
                          </select>
                        ) : field.type === 'checkbox' ? (
                          <div className="flex items-center">
                            <input type="checkbox" className="mr-2" disabled />
                            <span className="text-sm text-gray-700">{field.placeholder}</span>
                          </div>
                        ) : field.type === 'file' ? (
                          <div className="border-2 border-dashed border-gray-300 rounded-md p-4 text-center">
                            <Upload className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                            <p className="text-sm text-gray-600">点击上传文件</p>
                          </div>
                        ) : (
                          <input
                            type={field.type}
                            placeholder={field.placeholder}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md"
                            readOnly
                          />
                        )}
                      </div>
                    ))}

                    {formButtons.length > 0 && (
                      <div className="pt-4 border-t border-gray-200">
                        <div className="flex flex-wrap gap-3">
                          {formButtons.map((button) => (
                            <div
                              key={button.id}
                              className={`relative cursor-pointer ${
                                selectedButton?.id === button.id ? 'ring-2 ring-blue-500 ring-offset-2 rounded-md' : ''
                              }`}
                              onClick={() => {
                                setSelectedButton(button);
                                setSelectedField(null);
                              }}
                            >
                              <button
                                className={`px-4 py-2 rounded-md text-white font-medium ${
                                  button.color === 'green' ? 'bg-green-600' :
                                  button.color === 'red' ? 'bg-red-600' :
                                  button.color === 'yellow' ? 'bg-yellow-600' :
                                  button.color === 'blue' ? 'bg-blue-600' :
                                  button.color === 'purple' ? 'bg-purple-600' :
                                  'bg-gray-600'
                                }`}
                              >
                                <span className="mr-2">{button.icon}</span>
                                {button.label}
                              </button>
                              {selectedButton?.id === button.id && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    deleteButton(button.id);
                                  }}
                                  className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs hover:bg-red-600"
                                >
                                  ×
                                </button>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {formFields.length === 0 && formButtons.length === 0 && (
                      <div className="text-center py-12 text-gray-500">
                        <FileText className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p>从左侧工具栏拖拽字段到此处开始设计表单</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* 右侧属性面板 */}
            <div className="w-80 bg-white border-l border-gray-200 p-4 overflow-y-auto">
              {selectedField ? renderFieldConfig() : 
               selectedButton ? renderButtonConfig() : (
                <div className="text-center py-12 text-gray-500">
                  <Settings className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>选择字段或按钮进行配置</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'preview' && (
          <div className="h-full p-6 bg-gray-50">
            <div className="max-w-4xl mx-auto">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">表单预览</h2>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setPreviewDevice('mobile')}
                    className={`px-4 py-2 rounded-md ${
                      previewDevice === 'mobile'
                        ? 'bg-blue-600 text-white'
                        : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 inline mr-2" />
                    移动端
                  </button>
                  <button
                    onClick={() => setPreviewDevice('desktop')}
                    className={`px-4 py-2 rounded-md ${
                      previewDevice === 'desktop'
                        ? 'bg-blue-600 text-white'
                        : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <Monitor className="w-4 h-4 inline mr-2" />
                    桌面端
                  </button>
                </div>
              </div>

              <div className={`mx-auto ${previewDevice === 'mobile' ? 'max-w-sm' : 'max-w-2xl'}`}>
                {renderFormPreview()}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'test' && (
          <div className="h-full p-6 bg-gray-50">
            {renderTestTab()}
          </div>
        )}
      </div>
    </div>
  );
};