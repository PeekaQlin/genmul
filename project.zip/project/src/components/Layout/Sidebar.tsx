import React from 'react';
import { 
  Settings, 
  Users, 
  Database, 
  GitBranch, 
  Shield, 
  BarChart3,
  ChevronRight
} from 'lucide-react';

interface MenuItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  children?: MenuItem[];
  path?: string;
}

interface SidebarProps {
  activeMenu: string;
  onMenuChange: (menuId: string) => void;
}

const menuItems: MenuItem[] = [
  {
    id: 'workflow',
    label: '流程对接',
    icon: <GitBranch className="w-5 h-5" />,
    children: [
      { id: 'systems', label: '系统管理', icon: <Settings className="w-4 h-4" /> },
      { id: 'processes', label: '流程管理', icon: <GitBranch className="w-4 h-4" /> }
    ]
  },
  {
    id: 'form-design',
    label: '表单设计',
    icon: <Database className="w-5 h-5" />
  },
  {
    id: 'permissions',
    label: '角色权限',
    icon: <Shield className="w-5 h-5" />,
    children: [
      { id: 'admins', label: '管理员列表', icon: <Users className="w-4 h-4" /> },
      { id: 'permissions-config', label: '权限配置', icon: <Shield className="w-4 h-4" /> },
      { id: 'audit-logs', label: '审计日志', icon: <BarChart3 className="w-4 h-4" /> }
    ]
  },
  {
    id: 'data',
    label: '数据管理',
    icon: <Database className="w-5 h-5" />,
    children: [
      { id: 'approval-data', label: '审批数据', icon: <BarChart3 className="w-4 h-4" /> }
    ]
  },
  {
    id: 'user-feedback',
    label: '用户反馈',
    icon: <Database className="w-5 h-5" />
  }
];

export const Sidebar: React.FC<SidebarProps> = ({ activeMenu, onMenuChange }) => {
  return (
    <div className="w-64 bg-white border-r border-gray-200 h-full">
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-xl font-bold text-gray-900">审批流程管理</h1>
      </div>
      
      <nav className="mt-6 px-3">
        {menuItems.map((item) => (
          <div key={item.id} className="mb-2">
            <div
              className={`flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                activeMenu.startsWith(item.id) 
                  ? 'bg-blue-50 text-blue-700' 
                  : 'text-gray-700 hover:bg-gray-50'
              }`}
              onClick={() => onMenuChange(item.children ? item.children[0].id : item.id)}
            >
              <div className="flex items-center space-x-3">
                {item.icon}
                <span className="font-medium">{item.label}</span>
              </div>
              {item.children && <ChevronRight className="w-4 h-4" />}
            </div>
            
            {item.children && activeMenu.startsWith(item.id) && (
              <div className="ml-6 mt-2 space-y-1">
                {item.children.map((child) => (
                  <div
                    key={child.id}
                    className={`flex items-center space-x-3 px-3 py-2 rounded-md cursor-pointer transition-colors ${
                      activeMenu === child.id
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                    onClick={() => onMenuChange(child.id)}
                  >
                    {child.icon}
                    <span>{child.label}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>
    </div>
  );
};