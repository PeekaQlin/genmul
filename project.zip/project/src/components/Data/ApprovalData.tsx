import React, { useState } from 'react';
import { 
  Eye, 
  Filter, 
  RefreshCw, 
  Play, 
  Pause, 
  Trash2, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Clock,
  TrendingUp,
  Activity,
  BarChart3,
  Zap,
  GitCompare,
  Settings,
  User,
  Link,
  FileText,
  X
} from 'lucide-react';
import { Table } from '../Common/Table';
import { Modal } from '../Common/Modal';
import { ApprovalData, FlowHistoryItem } from '../../types';

interface RetryQueueItem {
  id: string;
  approvalId: string;
  approvalTitle: string;
  endpoint: string;
  errorMessage: string;
  errorCode: string;
  retryCount: number;
  maxRetries: number;
  status: 'pending' | 'retrying' | 'failed' | 'paused';
  lastRetryAt: string;
  nextRetryAt: string;
  createdAt: string;
}

interface ConflictData {
  id: string;
  approvalId: string;
  approvalTitle: string;
  approvalCenterStatus: string;
  businessSystemStatus: string;
  conflictType: string;
  severity: 'high' | 'medium' | 'low';
  detectedAt: string;
  systemName: string;
}

export const ApprovalDataList: React.FC = () => {
  const [approvalData] = useState<ApprovalData[]>([
    {
      id: 'AP001',
      systemId: '1',
      systemName: 'CRM系统',
      processId: '1',
      processTitle: '销售合同审批',
      applicant: '张三',
      applicantId: 'U001',
      currentApprover: '李经理',
      currentApproverId: 'U002',
      arrivalTime: '2024-01-15 09:30:00',
      currentNode: '部门经理审批',
      status: 'pending',
      createdAt: '2024-01-15 09:00:00',
      updatedAt: '2024-01-15 09:30:00',
      department: '销售部',
      apiEndpoint: '/api/contract/approve',
      processOwner: '张经理',
      flowHistory: [
        {
          id: 'H001',
          nodeId: 'N001',
          nodeName: '提交申请',
          operator: '张三',
          operatorId: 'U001',
          action: 'submit',
          comment: '申请销售合同审批',
          timestamp: '2024-01-15 09:00:00',
          duration: 0
        }
      ],
      relatedUsers: ['U001', 'U002']
    },
    {
      id: 'AP002',
      systemId: '2',
      systemName: 'ERP系统',
      processId: '2',
      processTitle: '采购申请审批',
      applicant: '王五',
      applicantId: 'U003',
      currentApprover: '赵总监',
      currentApproverId: 'U004',
      arrivalTime: '2024-01-14 14:20:00',
      currentNode: '总监审批',
      status: 'approved',
      createdAt: '2024-01-14 10:00:00',
      updatedAt: '2024-01-14 16:45:00',
      department: '采购部',
      apiEndpoint: '/api/expense/approve',
      processOwner: '李主管',
      flowHistory: [
        {
          id: 'H002',
          nodeId: 'N002',
          nodeName: '提交申请',
          operator: '王五',
          operatorId: 'U003',
          action: 'submit',
          comment: '申请采购办公用品',
          timestamp: '2024-01-14 10:00:00',
          duration: 0
        },
        {
          id: 'H003',
          nodeId: 'N003',
          nodeName: '部门审批',
          operator: '刘经理',
          operatorId: 'U005',
          action: 'approve',
          comment: '同意采购',
          timestamp: '2024-01-14 14:20:00',
          duration: 260
        },
        {
          id: 'H004',
          nodeId: 'N004',
          nodeName: '总监审批',
          operator: '赵总监',
          operatorId: 'U004',
          action: 'approve',
          comment: '批准采购申请',
          timestamp: '2024-01-14 16:45:00',
          duration: 145
        }
      ],
      relatedUsers: ['U003', 'U004', 'U005']
    },
    {
      id: 'AP003',
      systemId: '1',
      systemName: 'CRM系统',
      processId: '3',
      processTitle: '客户退款审批',
      applicant: '陈七',
      applicantId: 'U006',
      currentApprover: '孙经理',
      currentApproverId: 'U007',
      arrivalTime: '2024-01-13 11:15:00',
      currentNode: '财务审核',
      status: 'rejected',
      createdAt: '2024-01-13 09:30:00',
      updatedAt: '2024-01-13 15:20:00',
      department: '客服部',
      apiEndpoint: '/api/purchase/approve',
      processOwner: '王总监',
      flowHistory: [
        {
          id: 'H005',
          nodeId: 'N005',
          nodeName: '提交申请',
          operator: '陈七',
          operatorId: 'U006',
          action: 'submit',
          comment: '客户要求退款',
          timestamp: '2024-01-13 09:30:00',
          duration: 0
        },
        {
          id: 'H006',
          nodeId: 'N006',
          nodeName: '财务审核',
          operator: '孙经理',
          operatorId: 'U007',
          action: 'reject',
          comment: '不符合退款条件',
          timestamp: '2024-01-13 15:20:00',
          duration: 350
        }
      ],
      relatedUsers: ['U006', 'U007']
    },
    {
      id: 'AP004',
      systemId: '3',
      systemName: 'OA系统',
      processId: '4',
      processTitle: '员工转岗申请',
      applicant: '周八',
      applicantId: 'U008',
      currentApprover: '吴总',
      currentApproverId: 'U009',
      arrivalTime: '2024-01-12 16:00:00',
      currentNode: '总经理审批',
      status: 'timeout',
      createdAt: '2024-01-12 14:30:00',
      updatedAt: '2024-01-12 16:00:00',
      department: 'HR部',
      apiEndpoint: '/api/leave/approve',
      processOwner: '赵主任',
      flowHistory: [
        {
          id: 'H007',
          nodeId: 'N007',
          nodeName: '提交申请',
          operator: '周八',
          operatorId: 'U008',
          action: 'submit',
          comment: '申请从技术部转到产品部',
          timestamp: '2024-01-12 14:30:00',
          duration: 0
        }
      ],
      relatedUsers: ['U008', 'U009'],
      timeoutInfo: {
        occurredAt: '2024-01-12 16:00:00',
        reason: 'api_timeout',
        endpoint: '/api/hr/transfer-approval',
        errorMessage: 'Connection timeout after 30 seconds',
        retryCount: 3,
        lastRetryAt: '2024-01-12 16:15:00'
      }
    },
    {
      id: 'AP005',
      systemId: '2',
      systemName: 'ERP系统',
      processId: '5',
      processTitle: '设备维修申请',
      applicant: '郑九',
      applicantId: 'U010',
      currentApprover: '何主管',
      currentApproverId: 'U011',
      arrivalTime: '2024-01-11 10:45:00',
      currentNode: '设备主管审批',
      status: 'voided',
      createdAt: '2024-01-11 09:00:00',
      updatedAt: '2024-01-11 11:30:00',
      department: '设备部',
      flowHistory: [
        {
          id: 'H008',
          nodeId: 'N008',
          nodeName: '提交申请',
          operator: '郑九',
          operatorId: 'U010',
          action: 'submit',
          comment: '打印机需要维修',
          timestamp: '2024-01-11 09:00:00',
          duration: 0
        },
        {
          id: 'H009',
          nodeId: 'N009',
          nodeName: '作废申请',
          operator: '郑九',
          operatorId: 'U010',
          action: 'void',
          comment: '设备已自行修复',
          timestamp: '2024-01-11 11:30:00',
          duration: 150
        }
      ],
      relatedUsers: ['U010', 'U011']
    },
    {
      id: 'AP006',
      systemId: '1',
      systemName: 'CRM系统',
      processId: '6',
      processTitle: '客户信息变更',
      applicant: '冯十',
      applicantId: 'U012',
      currentApprover: '蒋经理',
      currentApproverId: 'U013',
      arrivalTime: '2024-01-10 13:20:00',
      currentNode: '数据审核',
      status: 'pending',
      createdAt: '2024-01-10 11:00:00',
      updatedAt: '2024-01-10 13:20:00',
      department: '数据部',
      flowHistory: [
        {
          id: 'H010',
          nodeId: 'N010',
          nodeName: '提交申请',
          operator: '冯十',
          operatorId: 'U012',
          action: 'submit',
          comment: '更新客户联系方式',
          timestamp: '2024-01-10 11:00:00',
          duration: 0
        }
      ],
      relatedUsers: ['U012', 'U013']
    },
    {
      id: 'AP007',
      systemId: '3',
      systemName: 'OA系统',
      processId: '7',
      processTitle: '年度预算申请',
      applicant: '卫十一',
      applicantId: 'U014',
      currentApprover: '蒋总',
      currentApproverId: 'U015',
      arrivalTime: '2024-01-09 15:30:00',
      currentNode: '总经理审批',
      status: 'approved',
      createdAt: '2024-01-09 09:00:00',
      updatedAt: '2024-01-09 17:45:00',
      department: '财务部',
      flowHistory: [
        {
          id: 'H011',
          nodeId: 'N011',
          nodeName: '提交申请',
          operator: '卫十一',
          operatorId: 'U014',
          action: 'submit',
          comment: '2024年度部门预算申请',
          timestamp: '2024-01-09 09:00:00',
          duration: 0
        },
        {
          id: 'H012',
          nodeId: 'N012',
          nodeName: '财务审核',
          operator: '钱会计',
          operatorId: 'U016',
          action: 'approve',
          comment: '预算合理，建议通过',
          timestamp: '2024-01-09 15:30:00',
          duration: 390
        },
        {
          id: 'H013',
          nodeId: 'N013',
          nodeName: '总经理审批',
          operator: '蒋总',
          operatorId: 'U015',
          action: 'approve',
          comment: '同意预算申请',
          timestamp: '2024-01-09 17:45:00',
          duration: 135
        }
      ],
      relatedUsers: ['U014', 'U015', 'U016']
    },
    {
      id: 'AP008',
      systemId: '2',
      systemName: 'ERP系统',
      processId: '8',
      processTitle: '库存盘点申请',
      applicant: '褚十二',
      applicantId: 'U017',
      currentApprover: '韩主管',
      currentApproverId: 'U018',
      arrivalTime: '2024-01-08 14:15:00',
      currentNode: '仓库主管审批',
      status: 'timeout',
      createdAt: '2024-01-08 10:30:00',
      updatedAt: '2024-01-08 14:15:00',
      department: '仓库部',
      flowHistory: [
        {
          id: 'H014',
          nodeId: 'N014',
          nodeName: '提交申请',
          operator: '褚十二',
          operatorId: 'U017',
          action: 'submit',
          comment: '月度库存盘点申请',
          timestamp: '2024-01-08 10:30:00',
          duration: 0
        }
      ],
      relatedUsers: ['U017', 'U018'],
      timeoutInfo: {
        occurredAt: '2024-01-08 14:15:00',
        reason: 'service_unavailable',
        endpoint: '/api/warehouse/inventory-check',
        errorMessage: 'Service temporarily unavailable',
        retryCount: 5,
        lastRetryAt: '2024-01-08 15:30:00'
      }
    },
    {
      id: 'AP009',
      systemId: '1',
      systemName: 'CRM系统',
      processId: '9',
      processTitle: '客户等级调整',
      applicant: '杨十三',
      applicantId: 'U019',
      currentApprover: '朱经理',
      currentApproverId: 'U020',
      arrivalTime: '2024-01-07 11:45:00',
      currentNode: '客户经理审批',
      status: 'timeout',
      createdAt: '2024-01-07 09:15:00',
      updatedAt: '2024-01-07 11:45:00',
      department: '客户部',
      flowHistory: [
        {
          id: 'H015',
          nodeId: 'N015',
          nodeName: '提交申请',
          operator: '杨十三',
          operatorId: 'U019',
          action: 'submit',
          comment: '客户升级为VIP等级',
          timestamp: '2024-01-07 09:15:00',
          duration: 0
        }
      ],
      relatedUsers: ['U019', 'U020'],
      timeoutInfo: {
        occurredAt: '2024-01-07 11:45:00',
        reason: 'response_timeout',
        endpoint: '/api/crm/customer-level-update',
        errorMessage: 'Response timeout after 60 seconds',
        retryCount: 3,
        lastRetryAt: '2024-01-07 12:00:00'
      }
    },
    {
      id: 'AP010',
      systemId: '3',
      systemName: 'OA系统',
      processId: '10',
      processTitle: '部门预算调整',
      applicant: '秦十四',
      applicantId: 'U021',
      currentApprover: '尤总',
      currentApproverId: 'U022',
      arrivalTime: '2024-01-06 16:20:00',
      currentNode: '总经理审批',
      status: 'voided',
      createdAt: '2024-01-06 14:00:00',
      updatedAt: '2024-01-06 17:30:00',
      department: '市场部',
      flowHistory: [
        {
          id: 'H016',
          nodeId: 'N016',
          nodeName: '提交申请',
          operator: '秦十四',
          operatorId: 'U021',
          action: 'submit',
          comment: '申请增加市场推广预算',
          timestamp: '2024-01-06 14:00:00',
          duration: 0
        },
        {
          id: 'H017',
          nodeId: 'N017',
          nodeName: '部门审批',
          operator: '许经理',
          operatorId: 'U023',
          action: 'approve',
          comment: '部门同意预算调整',
          timestamp: '2024-01-06 16:20:00',
          duration: 140
        },
        {
          id: 'H018',
          nodeId: 'N018',
          nodeName: '申请作废',
          operator: '秦十四',
          operatorId: 'U021',
          action: 'void',
          comment: '项目取消，不需要额外预算',
          timestamp: '2024-01-06 17:30:00',
          duration: 70
        }
      ],
      relatedUsers: ['U021', 'U022', 'U023']
    },
    {
      id: 'AP011',
      systemId: '1',
      systemName: 'CRM系统',
      processId: '11',
      processTitle: '客户退款处理',
      applicant: '何十五',
      applicantId: 'U024',
      currentApprover: '沈客服',
      currentApproverId: 'U025',
      arrivalTime: '2024-01-05 10:30:00',
      currentNode: '客服处理',
      status: 'rejected',
      createdAt: '2024-01-05 08:45:00',
      updatedAt: '2024-01-05 14:20:00',
      department: '客服部',
      flowHistory: [
        {
          id: 'H019',
          nodeId: 'N019',
          nodeName: '提交申请',
          operator: '何十五',
          operatorId: 'U024',
          action: 'submit',
          comment: '产品质量问题申请退款',
          timestamp: '2024-01-05 08:45:00',
          duration: 0
        },
        {
          id: 'H020',
          nodeId: 'N020',
          nodeName: '客服审核',
          operator: '沈客服',
          operatorId: 'U025',
          action: 'reject',
          comment: '超过退款期限，建议换货',
          timestamp: '2024-01-05 14:20:00',
          duration: 335
        }
      ],
      relatedUsers: ['U024', 'U025']
    },
    {
      id: 'AP012',
      systemId: '2',
      systemName: 'ERP系统',
      processId: '12',
      processTitle: '仓库调拨申请',
      applicant: '吕十六',
      applicantId: 'U026',
      currentApprover: '施主管',
      currentApproverId: 'U027',
      arrivalTime: '2024-01-04 13:15:00',
      currentNode: '仓库主管审批',
      status: 'pending',
      createdAt: '2024-01-04 11:30:00',
      updatedAt: '2024-01-04 13:15:00',
      department: '仓库部',
      flowHistory: [
        {
          id: 'H021',
          nodeId: 'N021',
          nodeName: '提交申请',
          operator: '吕十六',
          operatorId: 'U026',
          action: 'submit',
          comment: '从A仓调拨到B仓',
          timestamp: '2024-01-04 11:30:00',
          duration: 0
        }
      ],
      relatedUsers: ['U026', 'U027']
    },
    {
      id: 'AP013',
      systemId: '3',
      systemName: 'OA系统',
      processId: '13',
      processTitle: '培训申请审批',
      applicant: '张十七',
      applicantId: 'U028',
      currentApprover: '孔HR',
      currentApproverId: 'U029',
      arrivalTime: '2024-01-03 15:45:00',
      currentNode: 'HR审批',
      status: 'timeout',
      createdAt: '2024-01-03 14:00:00',
      updatedAt: '2024-01-03 15:45:00',
      department: 'HR部',
      flowHistory: [
        {
          id: 'H022',
          nodeId: 'N022',
          nodeName: '提交申请',
          operator: '张十七',
          operatorId: 'U028',
          action: 'submit',
          comment: '申请参加技术培训',
          timestamp: '2024-01-03 14:00:00',
          duration: 0
        }
      ],
      relatedUsers: ['U028', 'U029'],
      timeoutInfo: {
        occurredAt: '2024-01-03 15:45:00',
        reason: 'api_timeout',
        endpoint: '/api/hr/training-approval',
        errorMessage: 'API timeout - no response received',
        retryCount: 0,
        lastRetryAt: '2024-01-03 15:45:00'
      }
    },
    {
      id: 'AP014',
      systemId: '1',
      systemName: 'CRM系统',
      processId: '14',
      processTitle: '大客户合作协议',
      applicant: '曹十八',
      applicantId: 'U030',
      currentApprover: '严总',
      currentApproverId: 'U031',
      arrivalTime: '2024-01-02 09:20:00',
      currentNode: '总经理审批',
      status: 'approved',
      createdAt: '2024-01-02 08:00:00',
      updatedAt: '2024-01-02 16:30:00',
      department: '销售部',
      flowHistory: [
        {
          id: 'H023',
          nodeId: 'N023',
          nodeName: '提交申请',
          operator: '曹十八',
          operatorId: 'U030',
          action: 'submit',
          comment: '大客户年度合作协议',
          timestamp: '2024-01-02 08:00:00',
          duration: 0
        },
        {
          id: 'H024',
          nodeId: 'N024',
          nodeName: '销售经理审批',
          operator: '华经理',
          operatorId: 'U032',
          action: 'approve',
          comment: '合作条件优秀，建议通过',
          timestamp: '2024-01-02 09:20:00',
          duration: 80
        },
        {
          id: 'H025',
          nodeId: 'N025',
          nodeName: '销售总监审批',
          operator: '金总监',
          operatorId: 'U033',
          action: 'approve',
          comment: '战略客户，同意合作',
          timestamp: '2024-01-02 14:15:00',
          duration: 295
        },
        {
          id: 'H026',
          nodeId: 'N026',
          nodeName: '总经理审批',
          operator: '严总',
          operatorId: 'U031',
          action: 'approve',
          comment: '批准大客户合作协议',
          timestamp: '2024-01-02 16:30:00',
          duration: 135
        }
      ],
      relatedUsers: ['U030', 'U031', 'U032', 'U033']
    },
    {
      id: 'AP015',
      systemId: '2',
      systemName: 'ERP系统',
      processId: '15',
      processTitle: '紧急采购申请',
      applicant: '魏十九',
      applicantId: 'U034',
      currentApprover: '陶总',
      currentApproverId: 'U035',
      arrivalTime: '2024-01-01 11:30:00',
      currentNode: '总经理审批',
      status: 'timeout',
      createdAt: '2024-01-01 09:45:00',
      updatedAt: '2024-01-01 11:30:00',
      department: '采购部',
      flowHistory: [
        {
          id: 'H027',
          nodeId: 'N027',
          nodeName: '提交申请',
          operator: '魏十九',
          operatorId: 'U034',
          action: 'submit',
          comment: '生产线急需原材料',
          timestamp: '2024-01-01 09:45:00',
          duration: 0
        },
        {
          id: 'H028',
          nodeId: 'N028',
          nodeName: '采购经理审批',
          operator: '姜经理',
          operatorId: 'U036',
          action: 'approve',
          comment: '确实紧急，快速通过',
          timestamp: '2024-01-01 10:15:00',
          duration: 30
        },
        {
          id: 'H029',
          nodeId: 'N029',
          nodeName: '采购总监审批',
          operator: '戚总监',
          operatorId: 'U037',
          action: 'approve',
          comment: '紧急采购，同意',
          timestamp: '2024-01-01 11:30:00',
          duration: 75
        }
      ],
      relatedUsers: ['U034', 'U035', 'U036', 'U037'],
      timeoutInfo: {
        occurredAt: '2024-01-01 11:30:00',
        reason: 'network_error',
        endpoint: '/api/erp/urgent-purchase',
        errorMessage: 'Network connection interrupted',
        retryCount: 7,
        lastRetryAt: '2024-01-01 12:45:00'
      }
    },
    {
      id: 'AP016',
      systemId: '3',
      systemName: 'OA系统',
      processId: '16',
      processTitle: '系统升级申请',
      applicant: '谢二十',
      applicantId: 'U038',
      currentApprover: '邹CTO',
      currentApproverId: 'U039',
      arrivalTime: '2023-12-31 14:20:00',
      currentNode: 'CTO审批',
      status: 'rejected',
      createdAt: '2023-12-31 10:00:00',
      updatedAt: '2023-12-31 17:45:00',
      department: 'IT部',
      flowHistory: [
        {
          id: 'H030',
          nodeId: 'N030',
          nodeName: '提交申请',
          operator: '谢二十',
          operatorId: 'U038',
          action: 'submit',
          comment: '申请升级服务器系统',
          timestamp: '2023-12-31 10:00:00',
          duration: 0
        },
        {
          id: 'H031',
          nodeId: 'N031',
          nodeName: 'IT经理审批',
          operator: '喻经理',
          operatorId: 'U040',
          action: 'approve',
          comment: '系统确需升级，建议通过',
          timestamp: '2023-12-31 14:20:00',
          duration: 260
        },
        {
          id: 'H032',
          nodeId: 'N032',
          nodeName: 'CTO审批',
          operator: '邹CTO',
          operatorId: 'U039',
          action: 'reject',
          comment: '预算不足，延期到下季度',
          timestamp: '2023-12-31 17:45:00',
          duration: 205
        }
      ],
      relatedUsers: ['U038', 'U039', 'U040']
    },
    {
      id: 'AP017',
      systemId: '1',
      systemName: 'CRM系统',
      processId: '17',
      processTitle: '客户数据导入',
      applicant: '柏二一',
      applicantId: 'U041',
      currentApprover: '水主管',
      currentApproverId: 'U042',
      arrivalTime: '2023-12-30 16:10:00',
      currentNode: '数据主管审核',
      status: 'pending',
      createdAt: '2023-12-30 15:30:00',
      updatedAt: '2023-12-30 16:10:00',
      department: '数据部',
      flowHistory: [
        {
          id: 'H033',
          nodeId: 'N033',
          nodeName: '提交申请',
          operator: '柏二一',
          operatorId: 'U041',
          action: 'submit',
          comment: '批量导入新客户数据',
          timestamp: '2023-12-30 15:30:00',
          duration: 0
        }
      ],
      relatedUsers: ['U041', 'U042']
    },
    {
      id: 'AP018',
      systemId: '2',
      systemName: 'ERP系统',
      processId: '18',
      processTitle: '供应商资质审核',
      applicant: '窦二二',
      applicantId: 'U043',
      currentApprover: '章经理',
      currentApproverId: 'U044',
      arrivalTime: '2023-12-29 13:45:00',
      currentNode: '采购经理审核',
      status: 'timeout',
      createdAt: '2023-12-29 11:20:00',
      updatedAt: '2023-12-29 13:45:00',
      department: '采购部',
      flowHistory: [
        {
          id: 'H034',
          nodeId: 'N034',
          nodeName: '提交申请',
          operator: '窦二二',
          operatorId: 'U043',
          action: 'submit',
          comment: '新供应商资质审核',
          timestamp: '2023-12-29 11:20:00',
          duration: 0
        }
      ],
      relatedUsers: ['U043', 'U044'],
      timeoutInfo: {
        occurredAt: '2023-12-29 13:45:00',
        reason: 'service_unavailable',
        endpoint: '/api/erp/supplier-audit',
        errorMessage: 'Service under maintenance',
        retryCount: 2,
        lastRetryAt: '2023-12-29 14:30:00'
      }
    }
  ]);

  const retryQueueData = [
    {
      id: '1',
      processTitle: '合同审批流程',
      applicant: '张三',
      currentNode: '财务审核',
      processOwner: '李经理',
      errorTime: '2024-01-15T14:30:00Z',
      errorMessage: '连接超时: 无法连接到财务系统API (timeout after 30s)',
      retryCount: 3,
      nextRetryTime: '2024-01-15T15:00:00Z',
      status: 'retrying',
      apiEndpoint: '/api/finance/approval',
      logs: [
        { time: '2024-01-15T14:30:00Z', level: 'ERROR', message: '连接超时: 无法连接到财务系统API' },
        { time: '2024-01-15T14:35:00Z', level: 'INFO', message: '开始第1次重试' },
        { time: '2024-01-15T14:40:00Z', level: 'ERROR', message: '重试失败: 连接超时' }
      ]
    },
    {
      id: '2',
      processTitle: '费用报销流程',
      applicant: '李四',
      currentNode: '部门审批',
      processOwner: '王主管',
      errorTime: '2024-01-15T13:45:00Z',
      errorMessage: 'HTTP 500: 内部服务器错误 - 数据库连接池已满',
      retryCount: 2,
      nextRetryTime: '2024-01-15T14:15:00Z',
      status: 'failed',
      apiEndpoint: '/api/expense/approval',
      logs: [
        { time: '2024-01-15T13:45:00Z', level: 'ERROR', message: 'HTTP 500: 内部服务器错误' },
        { time: '2024-01-15T13:50:00Z', level: 'INFO', message: '开始第1次重试' },
        { time: '2024-01-15T13:55:00Z', level: 'ERROR', message: '重试失败: 数据库连接池已满' }
      ]
    },
    {
      id: '3',
      processTitle: '请假申请流程',
      applicant: '王五',
      currentNode: '人事审批',
      processOwner: '赵总监',
      errorTime: '2024-01-15T12:20:00Z',
      errorMessage: '认证失败: JWT token已过期 (expired at 2024-01-15T12:00:00Z)',
      retryCount: 1,
      nextRetryTime: '2024-01-15T12:50:00Z',
      status: 'pending',
      apiEndpoint: '/api/hr/leave-approval',
      logs: [
        { time: '2024-01-15T12:20:00Z', level: 'ERROR', message: '认证失败: JWT token已过期' },
        { time: '2024-01-15T12:25:00Z', level: 'INFO', message: '等待重试中...' }
      ]
    }
  ];

  const [retryQueue] = useState([
    {
      id: '1',
      processTitle: '合同审批流程',
      applicant: '张三',
      currentNode: '财务审核',
      processOwner: '李经理',
      failureReason: 'API超时',
      errorMessage: 'Connection timeout: Unable to connect to approval service at https://api.finance.company.com/approve within 30 seconds. Error code: ETIMEDOUT',
      errorTime: '2024-01-15T14:30:25Z',
      retryCount: 3,
      lastRetryAt: '2024-01-15T14:25:00Z',
      nextRetryAt: '2024-01-15T14:35:00Z',
      status: 'pending'
    },
    {
      id: '2',
      processTitle: '费用报销流程',
      applicant: '李四',
      currentNode: '部门审批',
      processOwner: '王主管',
      failureReason: '网络错误',
      errorMessage: 'Network error: Failed to establish connection to department approval system. DNS resolution failed for dept-approval.internal.com',
      errorTime: '2024-01-15T13:45:12Z',
      retryCount: 1,
      lastRetryAt: '2024-01-15T13:50:00Z',
      nextRetryAt: '2024-01-15T14:00:00Z',
      status: 'retrying'
    },
    {
      id: '3',
      processTitle: '请假申请流程',
      applicant: '王五',
      currentNode: '人事审批',
      processOwner: '陈总监',
      failureReason: '服务不可用',
      errorMessage: 'Service unavailable: HR approval service returned HTTP 503. Service is temporarily overloaded. Please try again later.',
      errorTime: '2024-01-15T12:20:08Z',
      retryCount: 5,
      lastRetryAt: '2024-01-15T13:00:00Z',
      nextRetryAt: '2024-01-15T13:30:00Z',
      status: 'failed'
    },
    {
      id: '4',
      processTitle: '采购申请流程',
      applicant: '赵六',
      currentNode: '总监审批',
      processOwner: '孙总监',
      failureReason: '认证失败',
      errorMessage: 'Authentication failed: Invalid API key provided. The API key may have expired or been revoked. Please check your credentials.',
      errorTime: '2024-01-15T11:15:33Z',
      retryCount: 2,
      lastRetryAt: '2024-01-15T11:30:00Z',
      nextRetryAt: '2024-01-15T12:00:00Z',
      status: 'pending'
    },
    {
      id: '5',
      processTitle: '出差申请流程',
      applicant: '孙七',
      currentNode: '预算审核',
      processOwner: '周经理',
      failureReason: '数据格式错误',
      errorMessage: 'Data format error: Invalid JSON payload. Expected field "budget_amount" as number, received string "五千元". Please check data format.',
      errorTime: '2024-01-15T10:45:17Z',
      retryCount: 1,
      lastRetryAt: '2024-01-15T11:00:00Z',
      nextRetryAt: '2024-01-15T11:15:00Z',
      status: 'retrying'
    }
  ]);

  const [conflictData] = useState<ConflictData[]>([
    {
      id: 'CF001',
      approvalId: 'AP001',
      approvalTitle: '销售合同审批',
      approvalCenterStatus: 'pending',
      businessSystemStatus: 'approved',
      conflictType: '状态不一致',
      severity: 'high',
      detectedAt: '2024-01-15 10:30:00',
      systemName: 'CRM系统'
    },
    {
      id: 'CF002',
      approvalId: 'AP006',
      approvalTitle: '客户信息变更',
      approvalCenterStatus: 'pending',
      businessSystemStatus: 'rejected',
      conflictType: '审批结果冲突',
      severity: 'medium',
      detectedAt: '2024-01-10 14:20:00',
      systemName: 'CRM系统'
    },
    {
      id: 'CF003',
      approvalId: 'AP012',
      approvalTitle: '仓库调拨申请',
      approvalCenterStatus: 'pending',
      businessSystemStatus: 'timeout',
      conflictType: '处理状态异常',
      severity: 'low',
      detectedAt: '2024-01-04 15:15:00',
      systemName: 'ERP系统'
    }
  ]);

  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [selectedApproval, setSelectedApproval] = useState<ApprovalData | null>(null);
  const [retryModalOpen, setRetryModalOpen] = useState(false);
  const [conflictModalOpen, setConflictModalOpen] = useState(false);
  const [selectedConflict, setSelectedConflict] = useState<ConflictData | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');
  const [systemFilter, setSystemFilter] = useState('');
  const [selectedRetryItems, setSelectedRetryItems] = useState<string[]>([]);
  const [logModalOpen, setLogModalOpen] = useState(false);
  const [selectedRetryItem, setSelectedRetryItem] = useState<any>(null);

  // 统计数据
  const stats = {
    pending: approvalData.filter(item => item.status === 'pending').length,
    timeout: approvalData.filter(item => item.status === 'timeout').length,
    todayCompleted: approvalData.filter(item => {
      const today = new Date().toDateString();
      const updatedDate = new Date(item.updatedAt).toDateString();
      return updatedDate === today && (item.status === 'approved' || item.status === 'rejected');
    }).length
  };

  // 状态分布数据
  const statusDistribution = [
    { name: '正常', value: approvalData.filter(item => ['pending', 'approved', 'rejected'].includes(item.status)).length, color: '#10B981' },
    { name: '预警', value: approvalData.filter(item => item.status === 'voided').length, color: '#F59E0B' },
    { name: '异常', value: approvalData.filter(item => item.status === 'timeout').length, color: '#EF4444' }
  ];

  // 效率排行数据
  const efficiencyRanking = {
    departments: [
      { name: '销售部', completed: 8, avgTime: 2.5 },
      { name: '财务部', completed: 6, avgTime: 3.2 },
      { name: '采购部', completed: 5, avgTime: 4.1 },
      { name: 'HR部', completed: 4, avgTime: 5.8 },
      { name: '客服部', completed: 3, avgTime: 6.2 }
    ],
    systems: [
      { name: 'CRM系统', completed: 12, avgTime: 3.1 },
      { name: 'ERP系统', completed: 10, avgTime: 3.8 },
      { name: 'OA系统', completed: 8, avgTime: 4.5 }
    ]
  };

  // 消息同步延迟热力图数据
  const [syncDelayData] = useState([
    { process: '数据库同步', node: '用户信息同步', avgDelay: 120, maxDelay: 300, count: 45 },
    { process: '数据库同步', node: '权限数据同步', avgDelay: 85, maxDelay: 180, count: 38 },
    { process: '数据库同步', node: '审批记录同步', avgDelay: 200, maxDelay: 450, count: 28 },
    { process: '第三方集成', node: 'ERP系统同步', avgDelay: 160, maxDelay: 400, count: 32 },
    { process: '第三方集成', node: 'CRM数据推送', avgDelay: 95, maxDelay: 200, count: 52 },
    { process: '第三方集成', node: 'OA系统通知', avgDelay: 75, maxDelay: 150, count: 67 },
    { process: '消息推送', node: '邮件通知', avgDelay: 45, maxDelay: 90, count: 89 },
    { process: '消息推送', node: '短信通知', avgDelay: 30, maxDelay: 75, count: 76 },
    { process: '消息推送', node: '微信推送', avgDelay: 55, maxDelay: 120, count: 58 }
  ]);

  // 延迟热力图数据
  const delayHeatmap = [
    { system: 'CRM系统', endpoint: '合同审批', delay: 120, status: 'good' },
    { system: 'CRM系统', endpoint: '客户管理', delay: 350, status: 'warning' },
    { system: 'CRM系统', endpoint: '数据同步', delay: 890, status: 'error' },
    { system: 'CRM系统', endpoint: '状态回调', delay: 200, status: 'good' },
    { system: 'ERP系统', endpoint: '采购审批', delay: 450, status: 'warning' },
    { system: 'ERP系统', endpoint: '库存管理', delay: 180, status: 'good' },
    { system: 'ERP系统', endpoint: '供应商审核', delay: 1200, status: 'error' },
    { system: 'ERP系统', endpoint: '财务对账', delay: 320, status: 'good' },
    { system: 'OA系统', endpoint: 'HR审批', delay: 680, status: 'warning' },
    { system: 'OA系统', endpoint: '预算管理', delay: 150, status: 'good' },
    { system: 'OA系统', endpoint: '培训申请', delay: 1500, status: 'error' },
    { system: 'OA系统', endpoint: '系统升级', delay: 280, status: 'good' }
  ];

  const columns = [
    {
      key: 'id',
      title: '审批ID',
      width: '8%'
    },
    {
      key: 'processTitle',
      title: '流程标题',
      width: '12%'
    },
    {
      key: 'applicant',
      title: '申请人',
      width: '8%'
    },
    {
      key: 'currentApprover',
      title: '当前审批人',
      width: '8%'
    },
    {
      key: 'apiEndpoint',
      title: '接口地址',
      width: '15%',
      render: (apiEndpoint: string) => (
        <div className="flex items-center space-x-1">
          <Link className="w-4 h-4 text-gray-400" />
          <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">
            {apiEndpoint}
          </code>
        </div>
      )
    },
    {
      key: 'processOwner',
      title: '流程负责人',
      width: '10%',
      render: (processOwner: string) => (
        <div className="flex items-center space-x-1">
          <User className="w-4 h-4 text-gray-400" />
          <span className="text-sm">{processOwner}</span>
        </div>
      )
    },
    {
      key: 'currentNode',
      title: '当前节点',
      width: '10%'
    },
    {
      key: 'status',
      title: '状态',
      width: '8%',
      render: (status: string, record: ApprovalData) => (
        <div className="flex items-center space-x-2">
          <span className={`px-2 py-1 rounded-full text-xs ${
            status === 'pending' ? 'bg-blue-100 text-blue-800' :
            status === 'approved' ? 'bg-green-100 text-green-800' :
            status === 'rejected' ? 'bg-red-100 text-red-800' :
            status === 'voided' ? 'bg-gray-100 text-gray-800' :
            'bg-orange-100 text-orange-800'
          }`}>
            {status === 'pending' ? '待审批' :
             status === 'approved' ? '已通过' :
             status === 'rejected' ? '已拒绝' :
             status === 'voided' ? '已作废' :
             '超时'}
          </span>
          {record.timeoutInfo && (
            <AlertTriangle className="w-4 h-4 text-orange-500" title="存在超时异常" />
          )}
        </div>
      )
    },
    {
      key: 'errorMessage',
      title: '错误信息',
      width: '15%',
      render: (errorMessage: string, record: ApprovalData) => {
        if (!errorMessage && record.status !== 'timeout') return '-';
        
        const message = errorMessage || (record.timeoutInfo ? 
          `${record.timeoutInfo.reason === 'api_timeout' ? 'API超时' : 
            record.timeoutInfo.reason === 'network_error' ? '网络错误' : 
            record.timeoutInfo.reason === 'service_unavailable' ? '服务不可用' : '响应超时'}` : '-');
        
        return (
          <div className="max-w-xs">
            <span className="text-xs text-red-600 truncate block" title={message}>
              {message}
            </span>
          </div>
        );
      }
    },
    {
      key: 'updatedAt',
      title: '最后更新时间',
      width: '10%',
      render: (updatedAt: string) => (
        <span className="text-sm text-gray-600">
          {new Date(updatedAt).toLocaleString()}
        </span>
      )
    },
    {
      key: 'department',
      title: '部门',
      width: '7%',
    },
    {
      key: 'systemName',
      title: '业务系统',
      width: '10%'
    },
    {
      key: 'actions',
      title: '操作',
      width: '15%',
      render: (_: any, record: ApprovalData) => (
        <button
          onClick={() => handleViewDetail(record)}
          className="p-1 text-blue-600 hover:bg-blue-50 rounded"
          title="查看详情"
        >
          <Eye className="w-4 h-4" />
        </button>
      )
    }
  ];

  const retryQueueColumns = [
    {
      key: 'processTitle',
      title: '流程标题',
      width: '12%'
    },
    {
      key: 'applicant',
      title: '申请人',
      width: '8%'
    },
    {
      key: 'currentNode',
      title: '当前节点',
      width: '10%'
    },
    {
      key: 'processOwner',
      title: '流程负责人',
      width: '8%'
    },
    {
      key: 'apiEndpoint',
      title: '接口地址',
      width: '12%',
      render: (apiEndpoint: string) => (
        <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">
          {apiEndpoint}
        </code>
      )
    },
    {
      key: 'errorTime',
      title: '报错时间',
      width: '10%',
      render: (errorTime: string) => (
        <div className="text-sm">
          {new Date(errorTime).toLocaleString()}
        </div>
      )
    },
    {
      key: 'errorMessage',
      title: '错误详情',
      width: '20%',
      render: (errorMessage: string) => (
        <div className="text-sm text-red-600 max-w-xs">
          <div className="truncate" title={errorMessage}>
            {errorMessage.length > 50 ? `${errorMessage.substring(0, 50)}...` : errorMessage}
          </div>
        </div>
      )
    },
    {
      key: 'retryCount',
      title: '重试次数',
      width: '6%'
    },
    {
      key: 'status',
      title: '状态',
      width: '6%',
      render: (status: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          status === 'retrying' ? 'bg-yellow-100 text-yellow-800' :
          status === 'failed' ? 'bg-red-100 text-red-800' :
          'bg-blue-100 text-blue-800'
        }`}>
          {status === 'retrying' ? '重试中' : status === 'failed' ? '失败' : '等待中'}
        </span>
      )
    },
    {
      key: 'actions',
      title: '操作',
      width: '8%',
      render: (_: any, record: any) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleRetryNow(record.id)}
            className="p-1 text-blue-600 hover:bg-blue-50 rounded"
            title="立即重试"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleViewLogs(record)}
            className="p-1 text-green-600 hover:bg-green-50 rounded"
            title="查看日志"
          >
            <FileText className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleCancelRetry(record.id)}
            className="p-1 text-red-600 hover:bg-red-50 rounded"
            title="取消重试"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  const retryColumns = [
    {
      key: 'approvalId',
      title: '审批编号',
      width: '12%',
      render: (approvalId: string) => (
        <code className="text-xs bg-gray-100 px-2 py-1 rounded">{approvalId}</code>
      )
    },
    {
      key: 'approvalTitle',
      title: '审批标题',
      width: '12%'
    },
    {
      key: 'currentNode',
      title: '当前节点',
      width: '12%'
    },
    {
      key: 'endpoint',
      title: '接口地址',
      width: '18%',
      render: (endpoint: string) => (
        <code className="text-xs bg-gray-100 px-2 py-1 rounded">{endpoint}</code>
      )
    },
    {
      key: 'errorMessage',
      title: '错误信息',
      width: '20%',
      render: (errorMessage: string, record: RetryQueueItem) => (
        <div>
          <div className="text-sm text-red-600">{errorMessage}</div>
          <div className="text-xs text-gray-500">错误码: {record.errorCode}</div>
        </div>
      )
    },
    {
      key: 'retryCount',
      title: '重试次数',
      width: '6%',
      render: (retryCount: number, record: RetryQueueItem) => (
        <span className={`px-2 py-1 rounded text-xs ${
          retryCount >= record.maxRetries ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
        }`}>
          {retryCount}/{record.maxRetries}
        </span>
      )
    },
    {
      key: 'status',
      title: '状态',
      width: '10%',
      render: (status: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          status === 'pending' ? 'bg-blue-100 text-blue-800' :
          status === 'retrying' ? 'bg-yellow-100 text-yellow-800' :
          status === 'failed' ? 'bg-red-100 text-red-800' :
          'bg-gray-100 text-gray-800'
        }`}>
          {status === 'pending' ? '等待中' :
           status === 'retrying' ? '重试中' :
           status === 'failed' ? '已失败' :
           '已暂停'}
        </span>
      )
    },
    {
      key: 'actions',
      title: '操作',
      width: '12%',
      render: (_: any, record: RetryQueueItem) => (
        <div className="flex space-x-1">
          <button
            onClick={() => handleRetryItem(record.id)}
            disabled={record.status === 'retrying'}
            className="p-1 text-green-600 hover:bg-green-50 rounded disabled:opacity-50"
            title="立即重试"
          >
            <Play className="w-4 h-4" />
          </button>
          <button
            onClick={() => handlePauseItem(record.id)}
            disabled={record.status === 'paused'}
            className="p-1 text-yellow-600 hover:bg-yellow-50 rounded disabled:opacity-50"
            title="暂停"
          >
            <Pause className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleDeleteItem(record.id)}
            className="p-1 text-red-600 hover:bg-red-50 rounded"
            title="删除"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  const conflictColumns = [
    {
      key: 'approvalTitle',
      title: '审批标题',
      width: '20%'
    },
    {
      key: 'systemName',
      title: '业务系统',
      width: '12%'
    },
    {
      key: 'approvalCenterStatus',
      title: '审批中心状态',
      width: '12%',
      render: (status: string) => (
        <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
          {status}
        </span>
      )
    },
    {
      key: 'businessSystemStatus',
      title: '业务系统状态',
      width: '12%',
      render: (status: string) => (
        <span className="px-2 py-1 bg-orange-100 text-orange-800 rounded text-xs">
          {status}
        </span>
      )
    },
    {
      key: 'severity',
      title: '严重程度',
      width: '10%',
      render: (severity: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          severity === 'high' ? 'bg-red-100 text-red-800' :
          severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
          'bg-green-100 text-green-800'
        }`}>
          {severity === 'high' ? '高' : severity === 'medium' ? '中' : '低'}
        </span>
      )
    },
    {
      key: 'detectedAt',
      title: '发现时间',
      width: '15%',
      render: (detectedAt: string) => (
        <span className="text-sm text-gray-600">
          {new Date(detectedAt).toLocaleString()}
        </span>
      )
    },
    {
      key: 'actions',
      title: '操作',
      width: '19%',
      render: (_: any, record: ConflictData) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleViewConflict(record)}
            className="px-2 py-1 text-blue-600 hover:bg-blue-50 rounded text-xs"
          >
            对比视图
          </button>
          <button
            onClick={() => handleFixConflict(record.id, 'approval_center')}
            className="px-2 py-1 text-green-600 hover:bg-green-50 rounded text-xs"
          >
            以审批中心为准
          </button>
          <button
            onClick={() => handleFixConflict(record.id, 'business_system')}
            className="px-2 py-1 text-orange-600 hover:bg-orange-50 rounded text-xs"
          >
            以业务系统为准
          </button>
        </div>
      )
    }
  ];

  const handleViewDetail = (approval: ApprovalData) => {
    setSelectedApproval(approval);
    setDetailModalOpen(true);
  };

  const handleRetryItem = (itemId: string) => {
    console.log('重试项目:', itemId);
  };

  const handlePauseItem = (itemId: string) => {
    console.log('暂停项目:', itemId);
  };

  const handleDeleteItem = (itemId: string) => {
    if (confirm('确定要删除这个重试项目吗？')) {
      console.log('删除项目:', itemId);
    }
  };

  const handleBatchRetry = () => {
    if (selectedRetryItems.length === 0) {
      alert('请选择要重试的项目');
      return;
    }
    if (confirm(`确定要批量重试选中的 ${selectedRetryItems.length} 个项目吗？`)) {
      console.log('批量重试:', selectedRetryItems);
      setSelectedRetryItems([]);
    }
  };

  const handleBatchPause = () => {
    if (selectedRetryItems.length === 0) {
      alert('请选择要暂停的项目');
      return;
    }
    if (confirm(`确定要批量暂停选中的 ${selectedRetryItems.length} 个项目吗？`)) {
      console.log('批量暂停:', selectedRetryItems);
      setSelectedRetryItems([]);
    }
  };

  const handleBatchDelete = () => {
    if (selectedRetryItems.length === 0) {
      alert('请选择要删除的项目');
      return;
    }
    if (confirm(`确定要批量删除选中的 ${selectedRetryItems.length} 个项目吗？`)) {
      console.log('批量删除:', selectedRetryItems);
      setSelectedRetryItems([]);
    }
  };

  const handleViewConflict = (conflict: ConflictData) => {
    setSelectedConflict(conflict);
    setConflictModalOpen(true);
  };

  const handleFixConflict = (conflictId: string, fixType: 'approval_center' | 'business_system') => {
    const fixTypeText = fixType === 'approval_center' ? '审批中心' : '业务系统';
    if (confirm(`确定要以${fixTypeText}的状态为准进行修复吗？`)) {
      console.log('修复冲突:', conflictId, fixType);
    }
  };

  const getDelayColor = (delay: number) => {
    if (delay < 300) return 'bg-green-500';
    if (delay < 600) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const handleRetry = (id: string) => {
    console.log('重试:', id);
  };

  const handlePause = (id: string) => {
    console.log('暂停:', id);
  };

  const handleDelete = (id: string) => {
    console.log('删除:', id);
  };

  const handleRetryNow = (id: string) => {
    console.log('立即重试:', id);
  };

  const handleCancelRetry = (id: string) => {
    console.log('取消重试:', id);
  };

  const handleViewLogs = (item: any) => {
    setSelectedRetryItem(item);
    setLogModalOpen(true);
  };

  const filteredData = approvalData.filter(item => {
    const matchesSearch = 
      item.processTitle.toLowerCase().includes(searchValue.toLowerCase()) ||
      item.applicant.toLowerCase().includes(searchValue.toLowerCase()) ||
      item.currentApprover.toLowerCase().includes(searchValue.toLowerCase());
    
    const matchesStatus = !statusFilter || item.status === statusFilter;
    const matchesSystem = !systemFilter || item.systemName === systemFilter;
    
    return matchesSearch && matchesStatus && matchesSystem;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">审批数据管理</h2>
          <p className="text-gray-600 mt-1">
            实时监控审批流程状态，管理异常数据和系统同步
          </p>
        </div>
      </div>

      {/* 实时统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100">待处理审批总数</p>
              <p className="text-3xl font-bold">{stats.pending}</p>
            </div>
            <Clock className="w-12 h-12 text-blue-200" />
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100">超时预警数量</p>
              <p className="text-3xl font-bold">{stats.timeout}</p>
            </div>
            <AlertTriangle className="w-12 h-12 text-orange-200" />
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100">今日已完成量</p>
              <p className="text-3xl font-bold">{stats.todayCompleted}</p>
            </div>
            <CheckCircle className="w-12 h-12 text-green-200" />
          </div>
        </div>
      </div>

      {/* 图表区域 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 流程状态分布图 */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2" />
            流程状态分布
          </h3>
          <div className="flex items-center justify-center">
            <div className="relative w-48 h-48">
              <svg viewBox="0 0 200 200" className="w-full h-full">
                {statusDistribution.map((item, index) => {
                  const total = statusDistribution.reduce((sum, s) => sum + s.value, 0);
                  const percentage = (item.value / total) * 100;
                  const angle = (percentage / 100) * 360;
                  const startAngle = statusDistribution.slice(0, index).reduce((sum, s) => sum + (s.value / total) * 360, 0);
                  
                  const x1 = 100 + 70 * Math.cos((startAngle - 90) * Math.PI / 180);
                  const y1 = 100 + 70 * Math.sin((startAngle - 90) * Math.PI / 180);
                  const x2 = 100 + 70 * Math.cos((startAngle + angle - 90) * Math.PI / 180);
                  const y2 = 100 + 70 * Math.sin((startAngle + angle - 90) * Math.PI / 180);
                  
                  const largeArcFlag = angle > 180 ? 1 : 0;
                  
                  return (
                    <path
                      key={index}
                      d={`M 100 100 L ${x1} ${y1} A 70 70 0 ${largeArcFlag} 1 ${x2} ${y2} Z`}
                      fill={item.color}
                      className="hover:opacity-80 transition-opacity"
                    />
                  );
                })}
                <circle cx="100" cy="100" r="35" fill="white" />
              </svg>
            </div>
          </div>
          <div className="mt-4 space-y-2">
            {statusDistribution.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                  <span className="text-sm text-gray-700">{item.name}</span>
                </div>
                <span className="text-sm font-medium text-gray-900">{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 审批效率Top5榜单 */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <TrendingUp className="w-5 h-5 mr-2" />
            审批效率Top5榜单
          </h3>
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">按部门排序</h4>
              <div className="space-y-2">
                {efficiencyRanking.departments.map((dept, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <div className="flex items-center space-x-3">
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white ${
                        index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : index === 2 ? 'bg-orange-500' : 'bg-blue-500'
                      }`}>
                        {index + 1}
                      </span>
                      <span className="text-sm font-medium">{dept.name}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">{dept.completed}件</div>
                      <div className="text-xs text-gray-500">{dept.avgTime}h平均</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">按系统排序</h4>
              <div className="space-y-2">
                {efficiencyRanking.systems.map((system, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <div className="flex items-center space-x-3">
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white ${
                        index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : 'bg-orange-500'
                      }`}>
                        {index + 1}
                      </span>
                      <span className="text-sm font-medium">{system.name}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">{system.completed}件</div>
                      <div className="text-xs text-gray-500">{system.avgTime}h平均</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 消息同步延迟热力图 */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
          <Activity className="w-5 h-5 mr-2" />
          消息同步延迟热力图
        </h3>
        <div className="overflow-x-auto">
          <div className="grid grid-cols-5 gap-2 min-w-max">
            <div className="p-2 font-medium text-gray-700">系统/接口</div>
            <div className="p-2 text-center font-medium text-gray-700">合同审批</div>
            <div className="p-2 text-center font-medium text-gray-700">客户管理</div>
            <div className="p-2 text-center font-medium text-gray-700">数据同步</div>
            <div className="p-2 text-center font-medium text-gray-700">状态回调</div>
            
            {['CRM系统', 'ERP系统', 'OA系统'].map((system) => (
              <React.Fragment key={system}>
                <div className="p-2 font-medium text-gray-700">{system}</div>
                {delayHeatmap
                  .filter(item => item.system === system)
                  .map((item, index) => (
                    <div
                      key={index}
                      className={`p-2 text-center text-white text-sm rounded ${getDelayColor(item.delay)}`}
                      title={`${item.endpoint}: ${item.delay}ms`}
                    >
                      {item.delay}ms
                    </div>
                  ))}
              </React.Fragment>
            ))}
          </div>
        </div>
        <div className="mt-4 flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-green-500 rounded"></div>
            <span>良好 (&lt;300ms)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-yellow-500 rounded"></div>
            <span>预警 (300-600ms)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-red-500 rounded"></div>
            <span>异常 (&gt;600ms)</span>
          </div>
        </div>
      </div>

      {/* 筛选器 */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <button className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
            <Filter className="w-4 h-4 mr-2" />
            筛选
          </button>
          <div className="flex space-x-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">全部状态</option>
              <option value="pending">待审批</option>
              <option value="approved">已通过</option>
              <option value="rejected">已拒绝</option>
              <option value="voided">已作废</option>
              <option value="timeout">超时</option>
            </select>
            <select
              value={systemFilter}
              onChange={(e) => setSystemFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">全部系统</option>
              <option value="CRM系统">CRM系统</option>
              <option value="ERP系统">ERP系统</option>
              <option value="OA系统">OA系统</option>
            </select>
          </div>
        </div>
      </div>

      {/* 审批数据表格 */}
      <Table
        columns={columns}
        data={filteredData}
        searchable
        searchValue={searchValue}
        onSearch={setSearchValue}
        pagination={{
          current: currentPage,
          total: filteredData.length,
          pageSize: 10,
          onChange: setCurrentPage
        }}
      />

      {/* 重试队列管理 */}
      <div className="bg-white rounded-lg border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900 flex items-center">
              <RefreshCw className="w-5 h-5 mr-2" />
              重试队列管理
            </h3>
            <div className="flex space-x-2">
              <button
                onClick={handleBatchRetry}
                className="px-3 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm"
              >
                批量重试
              </button>
              <button
                onClick={handleBatchPause}
                className="px-3 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 text-sm"
              >
                批量暂停
              </button>
              <button
                onClick={handleBatchDelete}
                className="px-3 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 text-sm"
              >
                批量删除
              </button>
            </div>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            管理所有同步失败的消息，支持手动重试和批量操作
          </p>
        </div>
        <div className="p-6">
          <Table
            columns={retryQueueColumns}
            data={retryQueueData}
          />
        </div>
      </div>

      {/* 冲突数据修复 */}
      <div className="bg-white rounded-lg border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 flex items-center">
            <GitCompare className="w-5 h-5 mr-2" />
            冲突数据修复
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            检测并修复审批中心与业务系统之间的状态不一致问题
          </p>
        </div>
        <div className="p-6">
          <Table
            columns={conflictColumns}
            data={conflictData}
          />
        </div>
      </div>

      {/* 审批详情模态框 */}
      <Modal
        open={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="审批详情"
        width="max-w-4xl"
      >
        {selectedApproval && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-3">基本信息</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">审批ID:</span>
                    <span>{selectedApproval.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">流程标题:</span>
                    <span>{selectedApproval.processTitle}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">申请人:</span>
                    <span>{selectedApproval.applicant}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">当前审批人:</span>
                    <span>{selectedApproval.currentApprover}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">当前节点:</span>
                    <span>{selectedApproval.currentNode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">状态:</span>
                    <span className={`px-2 py-1 rounded text-xs ${
                      selectedApproval.status === 'pending' ? 'bg-blue-100 text-blue-800' :
                      selectedApproval.status === 'approved' ? 'bg-green-100 text-green-800' :
                      selectedApproval.status === 'rejected' ? 'bg-red-100 text-red-800' :
                      selectedApproval.status === 'voided' ? 'bg-gray-100 text-gray-800' :
                      'bg-orange-100 text-orange-800'
                    }`}>
                      {selectedApproval.status === 'pending' ? '待审批' :
                       selectedApproval.status === 'approved' ? '已通过' :
                       selectedApproval.status === 'rejected' ? '已拒绝' :
                       selectedApproval.status === 'voided' ? '已作废' :
                       '超时'}
                    </span>
                  </div>
                </div>
              </div>
              
              {selectedApproval.timeoutInfo && (
                <div>
                  <h4 className="font-medium text-gray-900 mb-3 text-orange-600">超时信息</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">发生时间:</span>
                      <span>{new Date(selectedApproval.timeoutInfo.occurredAt).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">超时原因:</span>
                      <span>{selectedApproval.timeoutInfo.reason}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">接口地址:</span>
                      <code className="text-xs bg-gray-100 px-1 rounded">{selectedApproval.timeoutInfo.endpoint}</code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">错误信息:</span>
                      <span className="text-red-600">{selectedApproval.timeoutInfo.errorMessage}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">重试次数:</span>
                      <span>{selectedApproval.timeoutInfo.retryCount}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-3">流程历史</h4>
              <div className="space-y-3">
                {selectedApproval.flowHistory.map((item, index) => (
                  <div key={item.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm ${
                      item.action === 'submit' ? 'bg-blue-500' :
                      item.action === 'approve' ? 'bg-green-500' :
                      item.action === 'reject' ? 'bg-red-500' :
                      item.action === 'void' ? 'bg-gray-500' :
                      'bg-yellow-500'
                    }`}>
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h5 className="font-medium text-gray-900">{item.nodeName}</h5>
                        <span className="text-sm text-gray-500">
                          {new Date(item.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">
                        操作人: {item.operator} | 操作: {
                          item.action === 'submit' ? '提交' :
                          item.action === 'approve' ? '通过' :
                          item.action === 'reject' ? '拒绝' :
                          item.action === 'void' ? '作废' :
                          '其他'
                        }
                      </p>
                      {item.comment && (
                        <p className="text-sm text-gray-700 mt-1 italic">"{item.comment}"</p>
                      )}
                      {item.duration !== undefined && (
                        <p className="text-xs text-gray-500 mt-1">
                          处理时长: {item.duration} 分钟
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* 冲突对比模态框 */}
      <Modal
        open={conflictModalOpen}
        onClose={() => setConflictModalOpen(false)}
        title="冲突数据对比"
        width="max-w-4xl"
      >
        {selectedConflict && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-3 flex items-center">
                  <Settings className="w-4 h-4 mr-2" />
                  审批中心状态
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">状态:</span>
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                      {selectedConflict.approvalCenterStatus}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">最后更新:</span>
                    <span>2024-01-15 10:30:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">数据源:</span>
                    <span>审批中心数据库</span>
                  </div>
                </div>
              </div>
              
              <div className="border border-orange-200 rounded-lg p-4">
                <h4 className="font-medium text-orange-900 mb-3 flex items-center">
                  <Zap className="w-4 h-4 mr-2" />
                  业务系统状态
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">状态:</span>
                    <span className="px-2 py-1 bg-orange-100 text-orange-800 rounded text-xs">
                      {selectedConflict.businessSystemStatus}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">最后更新:</span>
                    <span>2024-01-15 09:45:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">数据源:</span>
                    <span>{selectedConflict.systemName}</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h4 className="font-medium text-red-900 mb-2 flex items-center">
                <AlertTriangle className="w-4 h-4 mr-2" />
                冲突分析
              </h4>
              <div className="text-sm text-red-800">
                <p>检测到状态不一致：审批中心显示为"{selectedConflict.approvalCenterStatus}"，
                而{selectedConflict.systemName}显示为"{selectedConflict.businessSystemStatus}"</p>
                <p className="mt-2">建议操作：请选择以哪个系统的状态为准进行数据修复</p>
              </div>
            </div>
            
            <div className="flex justify-center space-x-4">
              <button
                onClick={() => handleFixConflict(selectedConflict.id, 'approval_center')}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                以审批中心为准修复
              </button>
              <button
                onClick={() => handleFixConflict(selectedConflict.id, 'business_system')}
                className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700"
              >
                以业务系统为准修复
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* 日志查看模态框 */}
      <Modal
        open={logModalOpen}
        onClose={() => setLogModalOpen(false)}
        title="重试日志详情"
        width="max-w-4xl"
      >
        {selectedRetryItem && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">流程标题</label>
                  <p className="mt-1 text-sm text-gray-900">{selectedRetryItem.processTitle}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">申请人</label>
                  <p className="mt-1 text-sm text-gray-900">{selectedRetryItem.applicant}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">当前节点</label>
                  <p className="mt-1 text-sm text-gray-900">{selectedRetryItem.currentNode}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">流程负责人</label>
                  <p className="mt-1 text-sm text-gray-900">{selectedRetryItem.processOwner}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">接口地址</label>
                  <code className="mt-1 block text-sm bg-gray-100 px-3 py-2 rounded font-mono">
                    {selectedRetryItem.apiEndpoint}
                  </code>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">重试次数</label>
                  <p className="mt-1 text-sm text-gray-900">{selectedRetryItem.retryCount}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">状态</label>
                  <span className={`mt-1 inline-block px-2 py-1 rounded-full text-xs ${
                    selectedRetryItem.status === 'retrying' ? 'bg-yellow-100 text-yellow-800' :
                    selectedRetryItem.status === 'failed' ? 'bg-red-100 text-red-800' :
                    'bg-blue-100 text-blue-800'
                  }`}>
                    {selectedRetryItem.status === 'retrying' ? '重试中' : 
                     selectedRetryItem.status === 'failed' ? '失败' : '等待中'}
                  </span>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">下次重试时间</label>
                  <p className="mt-1 text-sm text-gray-900">
                    {new Date(selectedRetryItem.nextRetryTime).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">执行日志</label>
              <div className="bg-gray-900 rounded-lg p-4 max-h-96 overflow-y-auto">
                <div className="space-y-2">
                  {selectedRetryItem.logs.map((log: any, index: number) => (
                    <div key={index} className="flex items-start space-x-3 text-sm font-mono">
                      <span className="text-gray-400 whitespace-nowrap">
                        {new Date(log.time).toLocaleString()}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                        log.level === 'ERROR' ? 'bg-red-600 text-white' :
                        log.level === 'WARN' ? 'bg-yellow-600 text-white' :
                        'bg-blue-600 text-white'
                      }`}>
                        {log.level}
                      </span>
                      <span className="text-gray-300 flex-1">{log.message}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};