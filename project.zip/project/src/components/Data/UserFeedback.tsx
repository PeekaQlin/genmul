import React, { useState } from 'react';
import { MessageSquare, Eye, User, Globe, Download } from 'lucide-react';
import { Table } from '../Common/Table';
import { Modal } from '../Common/Modal';
import { UserFeedback } from '../../types';

export const UserFeedbackList: React.FC = () => {
  const [feedbacks, setFeedbacks] = useState<UserFeedback[]>([
    {
      id: '1',
      processTitle: '合同审批流程',
      feedbackUser: 'EMP001',
      feedbackUserName: '张三',
      feedbackTime: '2024-01-15T10:30:00Z',
      language: 'zh-CN',
      feedbackNode: '财务审核',
      content: '审批流程中的合同金额字段无法正确显示，显示为NaN，影响审批决策。建议修复数字格式化问题。',
      category: 'bug'
    },
    {
      id: '2',
      processTitle: '费用报销流程',
      feedbackUser: 'EMP002',
      feedbackUserName: '李四',
      feedbackTime: '2024-01-14T14:20:00Z',
      language: 'zh-CN',
      feedbackNode: '部门审批',
      content: '希望能在费用报销流程中增加发票OCR识别功能，自动提取发票信息，减少手工录入工作量。',
      category: 'feature'
    },
    {
      id: '3',
      processTitle: '请假申请流程',
      feedbackUser: 'EMP003',
      feedbackUserName: '王五',
      feedbackTime: '2024-01-13T09:15:00Z',
      language: 'en-US',
      feedbackNode: '人事审批',
      content: 'The leave application process is too slow. It takes more than 3 days to get approval for a simple sick leave. Can we optimize the approval workflow?',
      category: 'improvement'
    },
    {
      id: '4',
      processTitle: '采购申请流程',
      feedbackUser: 'EMP004',
      feedbackUserName: '赵六',
      feedbackTime: '2024-01-12T16:45:00Z',
      language: 'zh-CN',
      feedbackNode: '总监审批',
      content: '采购申请流程中的供应商选择界面加载很慢，经常出现超时错误。希望能优化性能。',
      category: 'bug'
    },
    {
      id: '5',
      processTitle: '出差申请流程',
      feedbackUser: 'EMP005',
      feedbackUserName: '孙七',
      feedbackTime: '2024-01-11T11:30:00Z',
      language: 'zh-CN',
      feedbackNode: '预算审核',
      content: '建议在出差申请中增加预算控制功能，当出差费用超过部门预算时自动提醒并需要额外审批。',
      category: 'feature'
    }
  ]);

  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [selectedFeedback, setSelectedFeedback] = useState<UserFeedback | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const columns = [
    {
      key: 'processTitle',
      title: '流程标题',
      width: '15%'
    },
    {
      key: 'feedbackUser',
      title: '反馈人',
      width: '10%',
      render: (feedbackUser: string, record: UserFeedback) => (
        <div className="flex items-center space-x-2">
          <User className="w-4 h-4 text-gray-400" />
          <div>
            <div className="font-medium">{record.feedbackUserName}</div>
            <div className="text-xs text-gray-500">{feedbackUser}</div>
          </div>
        </div>
      )
    },
    {
      key: 'feedbackNode',
      title: '反馈节点',
      width: '10%'
    },
    {
      key: 'feedbackTime',
      title: '反馈时间',
      width: '15%',
      render: (feedbackTime: string) => (
        <div className="text-sm">
          {new Date(feedbackTime).toLocaleString()}
        </div>
      )
    },
    {
      key: 'language',
      title: '语种',
      width: '10%',
      render: (language: string) => (
        <div className="flex items-center space-x-1">
          <Globe className="w-4 h-4 text-gray-400" />
          <span className="text-sm">
            {language === 'zh-CN' ? '中文' : language === 'en-US' ? 'English' : language}
          </span>
        </div>
      )
    },
    {
      key: 'content',
      title: '反馈内容',
      width: '35%',
      render: (content: string) => (
        <div className="text-sm text-gray-600 max-w-xs">
          <div className="truncate" title={content}>
            {content.length > 50 ? `${content.substring(0, 50)}...` : content}
          </div>
        </div>
      )
    },
    {
      key: 'actions',
      title: '操作',
      width: '8%',
      render: (_: any, record: UserFeedback) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleViewDetail(record)}
            className="p-1 text-blue-600 hover:bg-blue-50 rounded"
            title="查看详情"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  const handleViewDetail = (feedback: UserFeedback) => {
    setSelectedFeedback(feedback);
    setDetailModalOpen(true);
  };

  const handleExport = () => {
    // 准备导出数据
    const exportData = feedbacks.map(feedback => ({
      '流程标题': feedback.processTitle,
      '反馈人工号': feedback.feedbackUser,
      '反馈人姓名': feedback.feedbackUserName,
      '反馈时间': new Date(feedback.feedbackTime).toLocaleString(),
      '语种': feedback.language === 'zh-CN' ? '中文' : feedback.language === 'en-US' ? 'English' : feedback.language,
      '反馈节点': feedback.feedbackNode,
      '反馈内容': feedback.content
    }));

    // 转换为CSV格式
    const headers = Object.keys(exportData[0]);
    const csvContent = [
      headers.join(','),
      ...exportData.map(row => 
        headers.map(header => `"${row[header as keyof typeof row] || ''}"`).join(',')
      )
    ].join('\n');

    // 创建下载链接
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `用户反馈_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredFeedbacks = feedbacks.filter(feedback =>
    feedback.processTitle.toLowerCase().includes(searchValue.toLowerCase()) ||
    feedback.feedbackUserName.toLowerCase().includes(searchValue.toLowerCase()) ||
    feedback.content.toLowerCase().includes(searchValue.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">用户反馈</h2>
          <p className="text-gray-600 mt-1">
            收集和处理用户对审批流程的反馈意见
          </p>
        </div>
        <button
          onClick={handleExport}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Download className="w-4 h-4 mr-2" />
          导出数据
        </button>
      </div>

      <Table
        columns={columns}
        data={filteredFeedbacks}
        searchable
        searchValue={searchValue}
        onSearch={setSearchValue}
        pagination={{
          current: currentPage,
          total: filteredFeedbacks.length,
          pageSize: 10,
          onChange: setCurrentPage
        }}
      />

      {/* 详情模态框 */}
      <Modal
        open={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="反馈详情"
        width="max-w-3xl"
      >
        {selectedFeedback && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">流程标题</label>
                  <p className="mt-1 text-sm text-gray-900">{selectedFeedback.processTitle}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">反馈人</label>
                  <p className="mt-1 text-sm text-gray-900">
                    {selectedFeedback.feedbackUserName} ({selectedFeedback.feedbackUser})
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">反馈时间</label>
                  <p className="mt-1 text-sm text-gray-900">
                    {new Date(selectedFeedback.feedbackTime).toLocaleString()}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">语种</label>
                  <p className="mt-1 text-sm text-gray-900">
                    {selectedFeedback.language === 'zh-CN' ? '中文' : 'English'}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">反馈节点</label>
                  <p className="mt-1 text-sm text-gray-900">{selectedFeedback.feedbackNode}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">反馈内容</label>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-800 whitespace-pre-wrap">{selectedFeedback.content}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};