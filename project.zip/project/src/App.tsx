import React, { useState } from 'react';
import { AuthProvider } from './components/Auth/AuthProvider';
import { useAuth } from './hooks/useAuth';
import { LoginForm } from './components/Auth/LoginForm';
import { Header } from './components/Layout/Header';
import { Sidebar } from './components/Layout/Sidebar';
import { Breadcrumb } from './components/Layout/Breadcrumb';
import { SystemList } from './components/Workflow/SystemList';
import { ProcessList } from './components/Workflow/ProcessList';
import { NodeList } from './components/Workflow/NodeList';
import { AdminList } from './components/Permissions/AdminList';
import { PermissionConfig } from './components/Permissions/PermissionConfig';
import { AuditLogList } from './components/Permissions/AuditLog';
import { ApprovalDataList } from './components/Data/ApprovalData';
import { UserFeedbackList } from './components/Data/UserFeedback';
import { FormDesigner } from './components/FormDesign/FormDesigner';
import { BreadcrumbItem } from './types';

const AppContent: React.FC = () => {
  const { user } = useAuth();
  const [activeMenu, setActiveMenu] = useState('systems');
  const [currentView, setCurrentView] = useState<{
    type: 'systems' | 'processes' | 'nodes' | 'admins' | 'permissions-config' | 'audit-logs' | 'approval-data' | 'user-feedback' | 'form-design';
    data?: any;
  }>({ type: 'systems' });

  if (!user) {
    return <LoginForm />;
  }

  const handleMenuChange = (menuId: string) => {
    setActiveMenu(menuId);
    setCurrentView({ type: menuId as 'systems' | 'processes' | 'nodes' | 'admins' | 'permissions-config' | 'audit-logs' | 'approval-data' | 'user-feedback' | 'form-design' });
  };

  const handleViewProcesses = (systemId: string, systemName: string) => {
    setCurrentView({ 
      type: 'processes', 
      data: { systemId, systemName } 
    });
  };

  const handleViewNodes = (processId: string, processName: string) => {
    setCurrentView({ 
      type: 'nodes', 
      data: { processId, processName } 
    });
  };

  const handleBackToSystems = () => {
    setCurrentView({ type: 'systems' });
  };

  const handleBackToProcesses = () => {
    if (currentView.data) {
      setCurrentView({ 
        type: 'processes', 
        data: { 
          systemId: currentView.data.systemId, 
          systemName: currentView.data.systemName 
        } 
      });
    }
  };

  const getBreadcrumbItems = (): BreadcrumbItem[] => {
    const baseItems: BreadcrumbItem[] = [];
    
    switch (currentView.type) {
      case 'systems':
        return [{ label: '流程对接' }, { label: '系统管理' }];
      case 'processes':
        return [
          { label: '流程对接' },
          { label: '系统管理', path: 'systems' },
          { label: `${currentView.data?.systemName} - 流程管理` }
        ];
      case 'nodes':
        return [
          { label: '流程对接' },
          { label: '系统管理', path: 'systems' },
          { label: `流程管理`, path: 'processes' },
          { label: `${currentView.data?.processName} - 节点管理` }
        ];
      case 'admins':
        return [{ label: '角色权限' }, { label: '管理员列表' }];
      case 'permissions-config':
        return [{ label: '角色权限' }, { label: '权限配置' }];
      case 'audit-logs':
        return [{ label: '角色权限' }, { label: '审计日志' }];
      case 'approval-data':
        return [{ label: '数据管理' }, { label: '审批数据' }];
      case 'user-feedback':
        return [{ label: '用户反馈' }];
      case 'form-design':
        return [{ label: '表单设计' }];
      default:
        return baseItems;
    }
  };

  const renderContent = () => {
    switch (currentView.type) {
      case 'systems':
        return <SystemList onViewProcesses={handleViewProcesses} />;
      case 'processes':
        return (
          <ProcessList
            systemId={currentView.data?.systemId}
            systemName={currentView.data?.systemName}
            onBack={handleBackToSystems}
            onViewNodes={handleViewNodes}
          />
        );
      case 'nodes':
        return (
          <NodeList
            processId={currentView.data?.processId}
            processName={currentView.data?.processName}
            onBack={handleBackToProcesses}
          />
        );
      case 'admins':
        return <AdminList />;
      case 'permissions-config':
        return <PermissionConfig />;
      case 'audit-logs':
        return <AuditLogList />;
      case 'approval-data':
        return <ApprovalDataList />;
      case 'user-feedback':
        return <UserFeedbackList />;
      case 'form-design':
        return <FormDesigner />;
      default:
        return <SystemList onViewProcesses={handleViewProcesses} />;
    }
  };

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar activeMenu={activeMenu} onMenuChange={handleMenuChange} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto">
          <div className="p-6">
            <Breadcrumb 
              items={getBreadcrumbItems()}
              onNavigate={(path) => {
                if (path === 'systems') {
                  handleBackToSystems();
                } else if (path === 'processes') {
                  handleBackToProcesses();
                }
              }}
            />
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;