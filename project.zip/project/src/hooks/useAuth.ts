import { useState, useEffect, createContext, useContext } from 'react';
import { User, Grant, AuditLog } from '../types';

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  hasPermission: (dataType: 'system' | 'process' | 'node', dataId: string, action: 'view' | 'edit' | 'delete' | 'grant') => boolean;
  isSuperAdmin: () => boolean;
  canGrantPermissions: (dataType: 'system' | 'process' | 'node', dataId: string) => boolean;
  getGrants: () => Grant[];
  createGrant: (grant: Omit<Grant, 'id' | 'createdAt' | 'status'>) => Promise<boolean>;
  revokeGrant: (grantId: string) => Promise<boolean>;
  getAuditLogs: () => AuditLog[];
  logAuditEvent: (eventType: AuditLog['eventType'], targetEntity: string, targetId: string, details?: Record<string, any>) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const useAuthProvider = () => {
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem('user');
    return stored ? JSON.parse(stored) : null;
  });
  
  const [grants, setGrants] = useState<Grant[]>(() => {
    const stored = localStorage.getItem('grants');
    return stored ? JSON.parse(stored) : [];
  });
  
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const stored = localStorage.getItem('auditLogs');
    return stored ? JSON.parse(stored) : [];
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);
  
  useEffect(() => {
    localStorage.setItem('grants', JSON.stringify(grants));
  }, [grants]);
  
  useEffect(() => {
    localStorage.setItem('auditLogs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  const login = async (username: string, password: string): Promise<boolean> => {
    // Simulate API call with different user types
    if (username === 'admin' && password === 'admin') {
      const mockUser: User = {
        id: '1',
        username: 'admin',
        role: 'super_admin',
        email: 'admin@example.com',
        createdAt: '2024-01-01T00:00:00Z',
        status: 'active'
      };
      setUser(mockUser);
      return true;
    } else if (username === 'manager' && password === 'manager') {
      const mockUser: User = {
        id: '2',
        username: 'manager',
        role: 'admin',
        email: 'manager@example.com',
        createdAt: '2024-01-15T00:00:00Z',
        status: 'active'
      };
      setUser(mockUser);
      return true;
    } else if (username === 'operator' && password === 'operator') {
      const mockUser: User = {
        id: '3',
        username: 'operator',
        role: 'operator',
        email: 'operator@example.com',
        createdAt: '2024-01-20T00:00:00Z',
        status: 'active'
      };
      setUser(mockUser);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const hasPermission = (dataType: 'system' | 'process' | 'node', dataId: string, action: 'view' | 'edit' | 'delete' | 'grant'): boolean => {
    if (!user) return false;
    
    // 超级管理员拥有所有权限
    if (user.role === 'super_admin') return true;
    
    // 检查是否为创建者（创建者拥有所有权限）
    // 这里需要根据实际数据来判断，暂时模拟
    const isCreator = checkIsCreator(dataId, user.id);
    if (isCreator) return true;
    
    // 检查动态授权
    const validGrant = grants.find(grant => 
      grant.dataId === dataId &&
      grant.dataType === dataType &&
      grant.granteeId === user.id &&
      grant.status === 'active' &&
      grant.permissions.includes(action as any) &&
      (!grant.expiresAt || new Date(grant.expiresAt) > new Date())
    );
    
    return !!validGrant;
  };

  const checkIsCreator = (dataId: string, userId: string): boolean => {
    // 模拟检查创建者逻辑
    // 实际应用中应该查询数据库
    const creatorMap: Record<string, string> = {
      '1': '1', // 系统1由用户1创建
      '2': '1', // 系统2由用户1创建
      '3': '2', // 系统3由用户2创建
    };
    return creatorMap[dataId] === userId;
  };

  const canGrantPermissions = (dataType: 'system' | 'process' | 'node', dataId: string): boolean => {
    return hasPermission(dataType, dataId, 'grant');
  };

  const getGrants = (): Grant[] => {
    return grants;
  };

  const createGrant = async (grantData: Omit<Grant, 'id' | 'createdAt' | 'status'>): Promise<boolean> => {
    if (!user) return false;
    
    // 检查授权人是否有足够的权限
    const hasRequiredPermissions = grantData.permissions.every(permission => 
      hasPermission(grantData.dataType, grantData.dataId, permission as any)
    );
    
    if (!hasRequiredPermissions) {
      logAuditEvent('GRANT_CREATED', grantData.dataType, grantData.dataId, { 
        error: '试图授予超过自身范围的权限',
        errorCode: 40301 
      });
      return false;
    }
    
    const newGrant: Grant = {
      ...grantData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      status: 'active'
    };
    
    setGrants(prev => [...prev, newGrant]);
    logAuditEvent('GRANT_CREATED', grantData.dataType, grantData.dataId, { granteeId: grantData.granteeId });
    
    return true;
  };

  const revokeGrant = async (grantId: string): Promise<boolean> => {
    const grant = grants.find(g => g.id === grantId);
    if (!grant) return false;
    
    setGrants(prev => prev.map(g => 
      g.id === grantId ? { ...g, status: 'revoked' as const } : g
    ));
    
    logAuditEvent('GRANT_REVOKED', grant.dataType, grant.dataId, { granteeId: grant.granteeId });
    return true;
  };

  const getAuditLogs = (): AuditLog[] => {
    return auditLogs;
  };

  const logAuditEvent = (
    eventType: AuditLog['eventType'], 
    targetEntity: string, 
    targetId: string, 
    details?: Record<string, any>
  ) => {
    if (!user) return;
    
    const newLog: AuditLog = {
      id: Date.now().toString(),
      operatorId: user.id,
      operatorName: user.username,
      eventType,
      targetEntity,
      targetId,
      details,
      timestamp: new Date().toISOString()
    };
    
    setAuditLogs(prev => [...prev, newLog]);
  };

  const isSuperAdmin = (): boolean => {
    return user?.role === 'super_admin';
  };

  return {
    user,
    login,
    logout,
    hasPermission,
    isSuperAdmin,
    canGrantPermissions,
    getGrants,
    createGrant,
    revokeGrant,
    getAuditLogs,
    logAuditEvent
  };
};

export { AuthContext };