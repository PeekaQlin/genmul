export interface User {
  id: string;
  username: string;
  role: 'super_admin' | 'admin' | 'operator';
  email: string;
  createdAt: string;
  status: 'active' | 'inactive';
}

export interface System {
  id: string;
  name: string;
  description: string;
  creatorId: string;
  apiSecret?: string; // 敏感字段，仅创建者/超管可见
  createdAt: string;
  status: 'active' | 'inactive';
  processCount: number;
}

export interface Process {
  id: string;
  systemId: string;
  name: string;
  description: string;
  creatorId: string;
  apiSecret?: string; // 敏感字段
  createdAt: string;
  status: 'active' | 'inactive';
  nodeCount: number;
}

export interface Node {
  id: string;
  processId: string;
  name: string;
  type: 'start' | 'approval' | 'notification' | 'end';
  apiUrl?: string;
  parameters?: Record<string, any>;
  order: number;
  creatorId: string;
}

// 动态授权表
export interface Grant {
  id: string;
  dataId: string; // 被授权的数据ID
  dataType: 'system' | 'process' | 'node'; // 数据类型
  grantorId: string; // 授权人ID
  granteeId: string; // 被授权人ID
  granteeName: string; // 被授权人姓名
  permissions: ('view' | 'edit' | 'grant')[];
  expiresAt?: string; // 可选的过期时间
  createdAt: string;
  status: 'active' | 'revoked';
}

// 审计日志
export interface AuditLog {
  id: string;
  operatorId: string;
  operatorName: string;
  eventType: 'GRANT_CREATED' | 'GRANT_REVOKED' | 'SENSITIVE_FIELD_ACCESS' | 'DATA_ACCESS' | 'DATA_MODIFIED';
  targetEntity: string;
  targetId: string;
  details?: Record<string, any>;
  timestamp: string;
}

export interface ApprovalData {
  id: string;
  systemId: string;
  systemName: string;
  processId: string;
  processTitle: string;
  applicant: string;
  applicantId: string;
  currentApprover: string;
  currentApproverId: string;
  arrivalTime: string;
  currentNode: string;
  status: 'pending' | 'approved' | 'rejected' | 'voided' | 'timeout';
  createdAt: string;
  updatedAt: string;
  department: string;
  flowHistory: FlowHistoryItem[];
  relatedUsers: string[];
  apiEndpoint: string;
  processOwner: string;
  timeoutInfo?: {
    occurredAt: string;
    reason: 'api_timeout' | 'network_error' | 'service_unavailable' | 'response_timeout';
    endpoint?: string;
    errorMessage?: string;
    retryCount: number;
    lastRetryAt?: string;
  };
}

export interface FlowHistoryItem {
  id: string;
  nodeId: string;
  nodeName: string;
  operator: string;
  operatorId: string;
  action: 'submit' | 'approve' | 'reject' | 'transfer' | 'void' | 'rollback' | 'remind';
  comment?: string;
  timestamp: string;
  duration?: number;
}

export interface Permission {
  id: string;
  name: string;
  code: string;
  type: 'data' | 'function';
  children?: Permission[];
}

export interface BreadcrumbItem {
  label: string;
  path?: string;
}

export interface PermissionModalData {
  resourceType: 'system' | 'process' | 'node';
  resourceId: string;
  resourceName: string;
  currentPermissions: ResourcePermission[];
}

export interface UserFeedback {
  id: string;
  processTitle: string;
  feedbackUser: string;
  feedbackUserName: string;
  feedbackTime: string;
  language: 'zh-CN' | 'en-US';
  content: string;
  feedbackNode: string; // 反馈节点
  category: 'bug' | 'feature' | 'improvement';
}